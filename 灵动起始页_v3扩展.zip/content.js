/* ==========================================
   灵动起始页 - 双风格版本
   ========================================== */
(function mainIIFE() {
  'use strict';

  // ==================== 风格管理 ====================
  var STYLE_STORAGE_KEY = 'xs_ui_style';
  var currentStyle = 'neumorphism'; // 默认新拟态风格
  
  function initStyle() {
    var savedStyle = localStorage.getItem(STYLE_STORAGE_KEY);
    if (savedStyle && (savedStyle === 'neumorphism' || savedStyle === 'glass')) {
      currentStyle = savedStyle;
    } else {
      currentStyle = 'neumorphism';
    }
    document.body.setAttribute('data-theme', currentStyle);
    updateStyleUI();
  }
  
  function switchStyle(style) {
    if (style !== 'neumorphism' && style !== 'glass') return;
    currentStyle = style;
    document.body.setAttribute('data-theme', style);
    localStorage.setItem(STYLE_STORAGE_KEY, style);
    updateStyleUI();
    
    // 如果切换到新拟态风格，需要重置壁纸为默认（隐藏背景图）
    if (style === 'neumorphism') {
      resetWallpaperToDefault();
      showToast('已切换至新拟态风格');
    } else {
      // 切换到毛玻璃风格时，尝试加载已保存的壁纸
      loadWallpaperForGlass();
      showToast('已切换至毛玻璃风格');
    }
  }
  
  function updateStyleUI() {
    var neumorphismBtn = document.getElementById('styleNeumorphism');
    var glassBtn = document.getElementById('styleGlass');
    if (neumorphismBtn && glassBtn) {
      if (currentStyle === 'neumorphism') {
        neumorphismBtn.classList.add('active');
        glassBtn.classList.remove('active');
      } else {
        neumorphismBtn.classList.remove('active');
        glassBtn.classList.add('active');
      }
    }
  }
  
  // 新拟态风格下的默认背景（纯色）
  function resetWallpaperToDefault() {
    var wallpaperEl = document.getElementById('wallpaperRoot');
    if (wallpaperEl) {
      wallpaperEl.style.background = '';
      wallpaperEl.style.backgroundSize = '';
      wallpaperEl.style.backgroundImage = '';
    }
  }
  
  // 毛玻璃风格下加载壁纸
  function loadWallpaperForGlass() {
    storageAdapter.getItem(STORAGE_KEYS.WALLPAPER).then(function(saved) {
      if (saved && saved !== 'default' && currentStyle === 'glass') {
        applyWallpaperStyle(saved);
      } else if (currentStyle === 'glass') {
        // 使用默认背景图片（仅对毛玻璃风格生效）
        applyWallpaperStyle('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1920&q=80');
      }
    }).catch(function() {
      // 如果存储不可用，直接使用默认背景图片
      if (currentStyle === 'glass') {
        applyWallpaperStyle('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1920&q=80');
      }
    });
  }
  
  function applyWallpaperStyle(url) {
    var wallpaperEl = document.getElementById('wallpaperRoot');
    if (!wallpaperEl || currentStyle !== 'glass') return;
    wallpaperEl.style.background = 'url("' + url + '") center/cover no-repeat fixed';
    wallpaperEl.style.backgroundSize = 'cover';
  }

  // ==================== 存储适配器 ====================
  var storageAdapter = {
    isExtension: false,
    checkExtensionEnvironment: function checkExtensionEnvironment() {
      try {
        if (typeof chrome !== 'undefined') {
          if (chrome.runtime && chrome.runtime.id && 
              chrome.storage && typeof chrome.storage.local === 'object') {
            this.isExtension = true;
            return this.isExtension;
          }
        }
        if (typeof browser !== 'undefined' && browser.runtime && 
            browser.storage && typeof browser.storage.local === 'object') {
          this.isExtension = true;
          return this.isExtension;
        }
        if (window.location.protocol === 'chrome-extension:' || 
            window.location.protocol === 'moz-extension:' ||
            window.location.protocol === 'edge-extension:') {
          this.isExtension = true;
          return this.isExtension;
        }
      } catch (e) { this.isExtension = false; }
      return this.isExtension;
    },
    isStorageAvailable: function isStorageAvailable() {
      try {
        if (typeof chrome !== 'undefined' && 
            chrome.storage && 
            typeof chrome.storage.local === 'object' &&
            typeof chrome.storage.local.get === 'function') {
          return true;
        }
        if (typeof browser !== 'undefined' && 
            browser.storage && 
            typeof browser.storage.local === 'object' &&
            typeof browser.storage.local.get === 'function') {
          return true;
        }
        return false;
      } catch (e) {
        return false;
      }
    },
    getItem: function storageGetItem(key) {
      var self = this;
      if (this.isExtension && this.isStorageAvailable()) {
        return new Promise(function storageGetItemPromise(resolve) {
          try {
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
              chrome.storage.local.get([key], function storageGetItemCallback(result) {
                if (chrome.runtime && chrome.runtime.lastError) {
                  resolve(localStorage.getItem(key));
                } else {
                  resolve(result[key] || null);
                }
              });
            } 
            else if (typeof browser !== 'undefined' && browser.storage && browser.storage.local) {
              browser.storage.local.get([key]).then(function browserGetResult(result) {
                resolve(result[key] || null);
              }).catch(function browserGetError() {
                resolve(localStorage.getItem(key));
              });
            } else {
              resolve(localStorage.getItem(key));
            }
          } catch (e) {
            resolve(localStorage.getItem(key));
          }
        });
      }
      return Promise.resolve(localStorage.getItem(key));
    },
    setItem: function storageSetItem(key, value) {
      if (this.isExtension && this.isStorageAvailable()) {
        return new Promise(function storageSetItemPromise(resolve) {
          try {
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
              var setObjChrome = {}; setObjChrome[key] = value;
              chrome.storage.local.set(setObjChrome, function storageSetItemCallback() {
                resolve();
              });
            } 
            else if (typeof browser !== 'undefined' && browser.storage && browser.storage.local) {
              var setObjFirefox = {}; setObjFirefox[key] = value;
              browser.storage.local.set(setObjFirefox).then(function storageSetSuccess() {
                resolve();
              }).catch(function storageSetError() {
                localStorage.setItem(key, value);
                resolve();
              });
            } else {
              localStorage.setItem(key, value);
              resolve();
            }
          } catch (e) {
            localStorage.setItem(key, value);
            resolve();
          }
        });
      }
      localStorage.setItem(key, value);
      return Promise.resolve();
    },
    removeItem: function storageRemoveItem(key) {
      if (this.isExtension && this.isStorageAvailable()) {
        return new Promise(function storageRemoveItemPromise(resolve) {
          try {
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
              chrome.storage.local.remove([key], function storageRemoveItemCallback() { resolve(); });
            } 
            else if (typeof browser !== 'undefined' && browser.storage && browser.storage.local) {
              browser.storage.local.remove([key]).then(function storageRemoveSuccess() { resolve(); }).catch(function storageRemoveError() {
                localStorage.removeItem(key);
                resolve();
              });
            } else {
              localStorage.removeItem(key);
              resolve();
            }
          } catch (e) {
            localStorage.removeItem(key);
            resolve();
          }
        });
      }
      localStorage.removeItem(key);
      return Promise.resolve();
    }
  };

  // ==================== 工具函数 ====================
  function throttle(fn, limit) {
    var inThrottle = false, lastFn = null, lastTime = 0;
    return function throttledFunction() {
      var context = this, args = arguments;
      if (!inThrottle) {
        fn.apply(context, args); lastTime = Date.now(); inThrottle = true;
        setTimeout(function throttleTimeout() {
          inThrottle = false;
          if (lastFn) { lastFn(); lastFn = null; }
        }, limit);
      } else {
        lastFn = function lastFnWrapper() { fn.apply(context, args); };
      }
    };
  }
  function debounce(fn, wait) {
    wait = wait || 120;
    var timeout = null;
    return function debouncedFunction() {
      var context = this, args = arguments;
      clearTimeout(timeout);
      timeout = setTimeout(function debounceTimeout() { fn.apply(context, args); }, wait);
    };
  }
  function querySelector(selector, root) { return (root || document).querySelector(selector); }
  function querySelectorAll(selector, root) { return Array.from((root || document).querySelectorAll(selector)); }
  function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
  function deepClone(v) { return JSON.parse(JSON.stringify(v)); }
  function generateId(prefix) { return (prefix || 'id') + '_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9); }
  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function showToast(message) {
    if (!message) return;
    var old = querySelector('.__xs_toast__');
    if (old) old.remove();
    var toast = document.createElement('div');
    toast.className = '__xs_toast__';
    toast.textContent = message;
    toast.setAttribute('role', 'alert');
    document.body.appendChild(toast);
    requestAnimationFrame(function showToastRAF() { toast.style.opacity = '1'; });
    setTimeout(function showToastTimeout() {
      toast.style.opacity = '0';
      setTimeout(function removeToast() { toast.remove(); }, 260);
    }, 1800);
  }
  function isImageIcon(value) {
    if (!value) return false;
    return (/^(https?:\/\/|data:image\/|\.|\/)/i.test(value) || /\.(png|jpg|jpeg|gif|webp|svg)(\?.*)?$/i.test(value));
  }
  
  function handleImageError(img) {
    img.style.display = 'none';
    var parent = img.parentElement;
    if (parent) {
      parent.innerHTML = '<span class="iconify" data-icon="mdi:image-broken"></span>';
      if (window.Iconify) {
        try { Iconify.scan(parent); } catch (_) {}
      }
    }
  }
  
  function renderIconContent(item) {
    var icon = item.icon || '';
    if (isImageIcon(icon)) {
      return '<img class="custom-icon" src="' + escapeHtml(icon) + '" alt="" draggable="false" loading="lazy" decoding="async">';
    }
    return '<span class="iconify" data-icon="' + escapeHtml(icon || 'mdi:apps') + '"></span>';
  }
  function createApp(id, title, url, icon, bg) {
    var bgStyle = '';
    if (bg) {
      bgStyle = 'background:' + bg + ';';
    } else {
      bgStyle = 'background:rgba(255,255,255,.12);';
    }
    return { id: id, type: 'app', title: title, url: url, icon: icon, bgStyle: bgStyle };
  }
  function createFolder(id, title, children) {
    return { id: id, type: 'folder', title: title, children: children || [] };
  }

  // ==================== 常量 ====================
  var isTouchDevice = navigator.maxTouchPoints > 0 || window.matchMedia('(pointer: coarse)').matches;
  var LONG_PRESS_DURATION = isTouchDevice ? 300 : 430;
  var STORAGE_KEYS = {
    MAIN: 'xs_desktop_final_v2', WALLPAPER: 'xs_custom_wallpaper', CUSTOM_ENGINES: 'xs_custom_engines',
    GITHUB_CONFIG: 'xs_github_config', SEARCH_HISTORY: 'xs_search_history'
  };
  var PRESET_ENGINES = [
    { id: 'preset-0', name: 'Google', icon: 'streamline-logos:google-logo-solid', url: 'https://www.google.com/search?q=%s' },
    { id: 'preset-1', name: 'Bing', icon: 'fontisto:bing', url: 'https://www.bing.com/search?q=%s' },
    { id: 'preset-2', name: '百度', icon: 'simple-icons:baidu', url: 'https://www.baidu.com/s?wd=%s' },
    { id: 'preset-3', name: 'DuckDuckGo', icon: 'cib:duckduckgo', url: 'https://duckduckgo.com/?q=%s' },
    { id: 'preset-4', name: 'Yandex', icon: 'brandico:yandex', url: 'https://yandex.com/search/?text=%s' }
  ];
  var PRESET_BG_COLORS = [
    { name: '经典蓝', style: 'linear-gradient(135deg,#4f86ff,#2f5fff)' },
    { name: '天空蓝', style: 'linear-gradient(135deg,#00c6ff,#0072ff)' },
    { name: '深空灰', style: 'linear-gradient(135deg,#232526,#414345)' },
    { name: '热情红', style: 'linear-gradient(135deg,#ff4b2b,#ff416c)' },
    { name: '清新绿', style: 'linear-gradient(135deg,#00b09b,#96c93d)' },
    { name: '活力橙', style: 'linear-gradient(135deg,#ff7a18,#ffb347)' },
    { name: '湖水青', style: 'linear-gradient(135deg,#4facfe,#00f2fe)' },
    { name: '梦幻紫', style: 'linear-gradient(135deg,#667eea,#764ba2)' },
    { name: '阳光黄', style: 'linear-gradient(135deg,#f7971e,#ffd200)' },
    { name: '海洋蓝', style: 'linear-gradient(135deg,#43cea2,#185a9d)' },
    { name: '火焰红', style: 'linear-gradient(135deg,#fc4a1a,#f7b733)' },
    { name: '薄荷绿', style: 'linear-gradient(135deg,#11998e,#38ef7d)' },
    { name: '珊瑚粉', style: 'linear-gradient(135deg,#ff5f6d,#ffc371)' },
    { name: '皇家蓝', style: 'linear-gradient(135deg,#396afc,#2948ff)' },
    { name: '古铜棕', style: 'linear-gradient(135deg,#1d4350,#a43931)' },
    { name: '森林绿', style: 'linear-gradient(135deg,#56ab2f,#a8e063)' },
    { name: '冰川蓝', style: 'linear-gradient(135deg,#2193b0,#6dd5ed)' },
    { name: '霓虹紫', style: 'linear-gradient(135deg,#7f00ff,#e100ff)' },
    { name: '深紫罗兰', style: 'linear-gradient(135deg,#8e2de2,#4a00e0)' },
    { name: '玫瑰金', style: 'linear-gradient(135deg,#f4c4f3,#fc67fa)' },
    { name: '午夜蓝', style: 'linear-gradient(135deg,#0f2027,#203a43,#2c5364)' },
    { name: '日落橙', style: 'linear-gradient(135deg,#ff512f,#f09819)' },
    { name: '极光绿', style: 'linear-gradient(135deg,#00f260,#0575e6)' },
    { name: '樱花粉', style: 'linear-gradient(135deg,#ff9a9e,#fecfef)' }
  ];
  var VIRTUAL_SCROLL_THRESHOLD = 200;

  // ==================== 布局存储 ====================
  var layoutStore = {
    metrics: null, resizeObserver: null, virtualGridCache: [], gridVersion: 0,
    init: function layoutStoreInit() {
      this.metrics = this.calcMetrics(); this.applyMetrics();
      var self = this;
      if (window.ResizeObserver) {
        this.resizeObserver = new ResizeObserver(function resizeObserverCallback() { requestAnimationFrame(function handleResizeObserverRAF() { self.refresh(); }); });
        var appShell = querySelector('.app-shell');
        if (appShell) this.resizeObserver.observe(appShell);
      } else {
        window.addEventListener('resize', debounce(function windowResizeHandler() { self.refresh(); }, 120));
      }
    },
    calcMetrics: function layoutStoreCalcMetrics() {
      var vw = window.innerWidth, vh = window.innerHeight;
      var header = querySelector('.header-section'), dock = refs.dock;
      var headerHeight = header ? header.getBoundingClientRect().height : Math.round(vh * 0.22);
      var dockHeight = dock ? dock.getBoundingClientRect().height : 72;
      var columns; if (vw < 480) columns = 4; else if (vw < 768) columns = 5; else if (vw < 1024) columns = 7; else columns = 9;
      var pagePaddingX = vw < 480 ? 18 : vw < 768 ? 20 : vw < 1024 ? 30 : 40;
      var pagePaddingBottom = vw < 768 ? 30 : 36;
      var desktopHeight = Math.max(220, vh - headerHeight - dockHeight - 12);
      var availableWidth = Math.max(200, vw - pagePaddingX * 2);
      var availableHeight = Math.max(180, desktopHeight - pagePaddingBottom);
      var iconSizeByWidth = Math.floor(availableWidth / columns / 1.24);
      var iconSizeByHeight = Math.floor(availableHeight / 6 / 1.42);
      var iconSize = clamp(Math.min(iconSizeByWidth, iconSizeByHeight), 46, 84);
      var labelHeight = vw < 768 ? 20 : 22;
      var cellHeight = iconSize + labelHeight + 8;
      var colGap = clamp(Math.round(iconSize * 0.24), 8, 20);
      var rowGap = clamp(Math.round(iconSize * 0.30), 12, 24);
      var rows = Math.max(1, Math.floor((availableHeight + rowGap) / (cellHeight + rowGap)));
      var remainder = availableHeight - rows * (cellHeight + rowGap) + rowGap;
      if (remainder > (cellHeight + rowGap) * 0.45 && rows < 8) rows++;
      if (rows >= 6 && iconSize < 72 && availableHeight > (rows + 1) * (cellHeight + rowGap)) {
        iconSize = Math.min(84, iconSize + 4); cellHeight = iconSize + labelHeight + 8;
        rowGap = clamp(Math.round(iconSize * 0.30), 12, 24);
        rows = Math.max(1, Math.floor((availableHeight + rowGap) / (cellHeight + rowGap)));
      }
      var pageCapacity = rows * columns;
      return { viewportWidth: vw, viewportHeight: vh, columns: columns, rows: rows, pagePaddingX: pagePaddingX, pagePaddingBottom: pagePaddingBottom, iconSize: iconSize, labelHeight: labelHeight, cellWidth: iconSize, cellHeight: cellHeight, colGap: colGap, rowGap: rowGap, pageCapacity: pageCapacity };
    },
    applyMetrics: function layoutStoreApplyMetrics() {
      var m = this.metrics, root = document.documentElement;
      root.style.setProperty('--grid-columns', m.columns);
      root.style.setProperty('--icon-size', m.iconSize + 'px');
      root.style.setProperty('--grid-gap', m.rowGap + 'px ' + m.colGap + 'px');
      root.style.setProperty('--page-padding', '0 ' + m.pagePaddingX + 'px ' + m.pagePaddingBottom + 'px');
    },
    calcVirtualGrid: function layoutStoreCalcVirtualGrid(pageIndex) {
      var m = this.metrics, pageEl = querySelector('.page[data-page-index="' + pageIndex + '"]');
      if (!pageEl) return [];
      var pageRect = pageEl.getBoundingClientRect();
      var startX = pageRect.left + m.pagePaddingX, startY = pageRect.top + 8;
      var slots = [], cellWidthWithGap = m.cellWidth + m.colGap, cellHeightWithGap = m.cellHeight + m.rowGap;
      for (var row = 0; row < m.rows; row++) {
        for (var col = 0; col < m.columns; col++) {
          var x = startX + col * cellWidthWithGap, y = startY + row * cellHeightWithGap;
          slots.push({ row: row, col: col, index: row * m.columns + col, x: x, y: y, cx: x + m.cellWidth / 2, cy: y + m.cellHeight / 2, width: m.cellWidth, height: m.cellHeight });
        }
      }
      return slots;
    },
    precomputeAllGrids: function layoutStorePrecomputeAllGrids() {
      var pageCount = appStore.getPageCount();
      this.virtualGridCache = new Array(pageCount);
      for (var i = 0; i < pageCount; i++) this.virtualGridCache[i] = this.calcVirtualGrid(i);
      this.gridVersion++;
    },
    refresh: function layoutStoreRefresh() {
      var prevMetrics = this.metrics;
      this.metrics = this.calcMetrics(); this.applyMetrics();
      if (prevMetrics && (prevMetrics.columns !== this.metrics.columns || prevMetrics.rows !== this.metrics.rows || prevMetrics.pageCapacity !== this.metrics.pageCapacity)) {
        appStore.clampCurrentPage(); renderEngine.renderAll();
      }
      var self = this;
      if (window.requestIdleCallback) requestIdleCallback(function layoutStoreIdleCallback() { self.precomputeAllGrids(); }, { timeout: 100 });
      else this.precomputeAllGrids();
    }
  };

  // ==================== 应用状态存储 ====================
  var appStore = {
    currentPage: 0, currentQuote: '生活不是等待风暴过去，而是学会在雨中跳舞。',
    desktop: { items: [] }, dock: { id: 'dock', capacity: 6, items: [] }, folderModalId: null,
    getDefaultData: function appStoreGetDefaultData() {
      return {
        currentPage: 0, currentQuote: '生活不是等待风暴过去，而是学会在雨中跳舞。',
        desktop: {
          items: [
            createApp('app_baidu', '百度', 'https://www.baidu.com', 'simple-icons:baidu', 'linear-gradient(135deg,#4f86ff,#2f5fff)'),
            createApp('app_bilibili', '哔哩哔哩', 'https://www.bilibili.com', 'ri:bilibili-fill', 'linear-gradient(135deg,#00c6ff,#0072ff)'),
            createApp('app_github', 'GitHub', 'https://github.com', 'mdi:github', 'linear-gradient(135deg,#232526,#414345)'),
            createApp('app_music', '网易云', 'https://music.163.com', 'mdi:music-note', 'linear-gradient(135deg,#ff4b2b,#ff416c)'),
            createApp('app_map', '地图', 'https://ditu.amap.com', 'mdi:map-marker-radius', 'linear-gradient(135deg,#00b09b,#96c93d)'),
            createApp('app_taobao', '淘宝', 'https://www.taobao.com', 'ri:shopping-bag-3-fill', 'linear-gradient(135deg,#ff7a18,#ffb347)'),
            createApp('app_weather', '天气', 'https://tianqi.qq.com', 'mdi:weather-partly-cloudy', 'linear-gradient(135deg,#4facfe,#00f2fe)'),
            createApp('app_mail', '邮箱', 'https://mail.qq.com', 'mdi:email-outline', 'linear-gradient(135deg,#667eea,#764ba2)'),
            createApp('app_photos', '相册', 'https://image.baidu.com', 'mdi:image-multiple', 'linear-gradient(135deg,#f7971e,#ffd200)'),
            createApp('app_notes', '笔记', 'https://note.youdao.com', 'mdi:notebook-outline', 'linear-gradient(135deg,#43cea2,#185a9d)'),
            createApp('app_video', '视频', 'https://v.qq.com', 'mdi:play-circle-outline', 'linear-gradient(135deg,#fc4a1a,#f7b733)'),
            createApp('app_docs', '文档', 'https://docs.qq.com', 'mdi:file-document-outline', 'linear-gradient(135deg,#11998e,#38ef7d)'),
            createApp('app_jd', '京东', 'https://www.jd.com', 'mdi:cart-outline', 'linear-gradient(135deg,#ff5f6d,#ffc371)'),
            createApp('app_calendar', '日历', 'https://calendar.google.com', 'mdi:calendar-month-outline', 'linear-gradient(135deg,#396afc,#2948ff)'),
            createApp('app_clock', '时钟', 'https://time.is', 'mdi:clock-outline', 'linear-gradient(135deg,#1d4350,#a43931)'),
            createApp('app_drive', '云盘', 'https://drive.google.com', 'mdi:cloud-upload-outline', 'linear-gradient(135deg,#56ab2f,#a8e063)'),
            createApp('app_forum', '知乎', 'https://www.zhihu.com', 'mdi:forum-outline', 'linear-gradient(135deg,#2193b0,#6dd5ed)'),
            createApp('app_design', '设计', 'https://www.canva.com', 'mdi:palette-outline', 'linear-gradient(135deg,#7f00ff,#e100ff)'),
            createApp('app_book', '阅读', 'https://weread.qq.com', 'mdi:book-open-page-variant-outline', 'linear-gradient(135deg,#8e2de2,#4a00e0)'),
            createApp('app_sync', '云同步', '#sync', 'mdi:cloud-sync', 'linear-gradient(135deg,#00c6ff,#0072ff)')
          ]
        },
        dock: { id: 'dock', capacity: 6, items: [
          createApp('dock_phone', '电话', 'https://www.google.com/search?q=%E7%94%B5%E8%AF%9D', 'mdi:phone-outline', 'linear-gradient(135deg,#00c853,#43a047)'),
          createApp('dock_message', '消息', 'https://mail.qq.com', 'mdi:message-outline', 'linear-gradient(135deg,#36d1dc,#5b86e5)'),
          createApp('dock_browser', '浏览器', 'https://www.google.com', 'mdi:web', 'linear-gradient(135deg,#f7971e,#ffd200)'),
          createApp('dock_album', '相册', 'https://image.baidu.com', 'mdi:image-outline', 'linear-gradient(135deg,#ff512f,#dd2476)')
        ]}
      };
    },
    applyDefaults: function appStoreApplyDefaults() {
      var defaults = this.getDefaultData();
      this.currentPage = defaults.currentPage; this.currentQuote = defaults.currentQuote;
      this.desktop = defaults.desktop; this.dock = defaults.dock;
    },
    load: function appStoreLoad() {
      var self = this;
      storageAdapter.getItem(STORAGE_KEYS.MAIN).then(function appStoreLoadThen(raw) {
        if (!raw) { self.applyDefaults(); }
        else {
          try {
            var data = JSON.parse(raw); self.applyDefaults();
            if (typeof data.currentPage === 'number') self.currentPage = data.currentPage;
            if (typeof data.currentQuote === 'string') self.currentQuote = data.currentQuote;
            if (data.desktop && data.desktop.items) self.desktop.items = data.desktop.items;
            if (data.dock && data.dock.items) self.dock.items = data.dock.items;
            if (data.currentEngineId) {
              var savedEngine = searchStore.engines.find(function findSavedEngine(e) { return e.id === data.currentEngineId; });
              if (savedEngine) {
                searchStore.currentEngine = savedEngine;
                searchStore.syncIcons();
              }
            }
          } catch (e) { self.applyDefaults(); }
        }
        renderEngine.renderAll(); syncQuoteUI();
      }).catch(function appStoreLoadCatch() { self.applyDefaults(); renderEngine.renderAll(); });
    },
    save: function appStoreSave() {
      var payload = {
        currentPage: this.currentPage,
        currentQuote: this.currentQuote,
        desktop: this.desktop,
        dock: this.dock,
        currentEngineId: searchStore.currentEngine ? searchStore.currentEngine.id : null
      };
      storageAdapter.setItem(STORAGE_KEYS.MAIN, JSON.stringify(payload));
    },
    getPageCount: function appStoreGetPageCount() {
      var cap = layoutStore.metrics ? layoutStore.metrics.pageCapacity : 20;
      var pages = Math.ceil(this.desktop.items.length / cap);
      return Math.max(1, pages);
    },
    clampCurrentPage: function appStoreClampCurrentPage() { this.currentPage = clamp(this.currentPage, 0, this.getPageCount() - 1); },
    getItemById: function appStoreGetItemById(id) {
      var item = this.desktop.items.find(function findInDesktop(i) { return i.id === id; });
      if (item) return item; item = this.dock.items.find(function findInDock(i) { return i.id === id; });
      if (item) return item;
      for (var i = 0; i < this.desktop.items.length; i++) {
        var top = this.desktop.items[i];
        if (top.type === 'folder') { var child = top.children.find(function findInFolder(c) { return c.id === id; }); if (child) return child; }
      }
      return null;
    },
    locateItem: function appStoreLocateItem(id) {
      var desktopIndex = this.desktop.items.findIndex(function findDesktopIndex(i) { return i.id === id; });
      if (desktopIndex >= 0) return { scope: 'desktop', globalIndex: desktopIndex, pageIndex: Math.floor(desktopIndex / layoutStore.metrics.pageCapacity), localIndex: desktopIndex % layoutStore.metrics.pageCapacity };
      var dockIndex = this.dock.items.findIndex(function findDockIndex(i) { return i.id === id; });
      if (dockIndex >= 0) return { scope: 'dock', index: dockIndex };
      for (var j = 0; j < this.desktop.items.length; j++) {
        var item = this.desktop.items[j];
        if (item.type === 'folder') { var childIndex = item.children.findIndex(function findChildIndex(c) { return c.id === id; }); if (childIndex >= 0) return { scope: 'folder', folderId: item.id, index: childIndex }; }
      }
      return null;
    },
    removeItemByLocation: function appStoreRemoveItemByLocation(loc) {
      if (!loc) return null;
      if (loc.scope === 'desktop') return this.desktop.items.splice(loc.globalIndex, 1)[0] || null;
      if (loc.scope === 'dock') return this.dock.items.splice(loc.index, 1)[0] || null;
      if (loc.scope === 'folder') {
        var folder = this.desktop.items.find(function findFolder(i) { return i.id === loc.folderId && i.type === 'folder'; });
        if (!folder) return null; return folder.children.splice(loc.index, 1)[0] || null;
      }
      return null;
    },
    cleanupFolders: function appStoreCleanupFolders() {
      this.desktop.items = this.desktop.items.flatMap(function cleanupFolderFlatMap(item) {
        if (item.type !== 'folder') return [item];
        if (item.children.length === 0) return [];
        if (item.children.length === 1) return [item.children[0]];
        return [item];
      });
      if (this.folderModalId) {
        var folder = this.desktop.items.find(function findModalFolder(i) { return i.id === this.folderModalId && i.type === 'folder'; }.bind(this));
        if (!folder) this.folderModalId = null;
      }
    },
    insertDesktopItem: function appStoreInsertDesktopItem(item, globalIndex) { this.desktop.items.splice(clamp(globalIndex, 0, this.desktop.items.length), 0, item); },
    insertDockItem: function appStoreInsertDockItem(item, index) {
      if (!item || item.type === 'folder') return false;
      var i = clamp(index, 0, this.dock.items.length); this.dock.items.splice(i, 0, item);
      if (this.dock.items.length > this.dock.capacity) { var overflow = this.dock.items.pop(); if (overflow) this.desktop.items.push(overflow); }
      return true;
    },
    insertFolderChild: function appStoreInsertFolderChild(folderId, item, index) {
      var folder = this.desktop.items.find(function findTargetFolder(i) { return i.id === folderId && i.type === 'folder'; });
      if (!folder) return; folder.children.splice(clamp(index, 0, folder.children.length), 0, item);
    },
    swapItems: function appStoreSwapItems(itemAId, itemBId) {
      var locA = this.locateItem(itemAId), locB = this.locateItem(itemBId);
      if (!locA || !locB) return false;
      var itemA, itemB, containerA, containerB, indexA, indexB;
      if (locA.scope === 'desktop') { containerA = this.desktop.items; indexA = locA.globalIndex; itemA = containerA[indexA]; }
      else if (locA.scope === 'dock') { containerA = this.dock.items; indexA = locA.index; itemA = containerA[indexA]; }
      else if (locA.scope === 'folder') {
        var folderA = this.desktop.items.find(function findFolderA(i) { return i.id === locA.folderId && i.type === 'folder'; });
        containerA = folderA ? folderA.children : null; indexA = locA.index; itemA = containerA ? containerA[indexA] : null;
      }
      if (locB.scope === 'desktop') { containerB = this.desktop.items; indexB = locB.globalIndex; itemB = containerB[indexB]; }
      else if (locB.scope === 'dock') { containerB = this.dock.items; indexB = locB.index; itemB = containerB[indexB]; }
      else if (locB.scope === 'folder') {
        var folderB = this.desktop.items.find(function findFolderB(i) { return i.id === locB.folderId && i.type === 'folder'; });
        containerB = folderB ? folderB.children : null; indexB = locB.index; itemB = containerB ? containerB[indexB] : null;
      }
      if (!containerA || !containerB || !itemA || !itemB) return false;
      if (containerA === containerB) { var temp = containerA[indexA]; containerA[indexA] = containerA[indexB]; containerA[indexB] = temp; }
      else {
        containerA.splice(indexA, 1); containerB.splice(indexB, 1);
        var newIndexB = indexB; if (containerA === containerB && indexA < indexB) newIndexB--;
        containerA.splice(indexA, 0, itemB); containerB.splice(newIndexB, 0, itemA);
      }
      return true;
    },
    insertItemAt: function appStoreInsertItemAt(itemId, target) {
      var loc = this.locateItem(itemId); if (!loc) return false;
      var item = this.removeItemByLocation(loc); if (!item) return false;
      var isCrossContainer = target.sourceScope && target.sourceScope !== target.container;
      if (target.container === 'desktop') {
        var globalIndex = target.globalIndex !== undefined ? target.globalIndex : target.pageIndex * layoutStore.metrics.pageCapacity + target.insertIndex;
        if (isCrossContainer && globalIndex > this.desktop.items.length) globalIndex = this.desktop.items.length;
        this.insertDesktopItem(item, globalIndex);
      } else if (target.container === 'dock') {
        if (item.type === 'folder') {
          var returnIndex = target.sourceGlobalIndex !== undefined ? target.sourceGlobalIndex : this.desktop.items.length;
          this.insertDesktopItem(item, returnIndex); showToast('文件夹暂不支持放入 Dock'); return false;
        }
        var dockIndex = target.index; if (isCrossContainer) dockIndex = Math.min(dockIndex, this.dock.items.length);
        var success = this.insertDockItem(item, dockIndex); if (!success) this.insertDesktopItem(item, this.desktop.items.length);
      } else if (target.container === 'folder') {
        var folderIndex = target.index;
        var folder = this.desktop.items.find(function findTargetFolder2(i) { return i.id === target.folderId && i.type === 'folder'; });
        if (folder && isCrossContainer) folderIndex = Math.min(folderIndex, folder.children.length);
        this.insertFolderChild(target.folderId, item, folderIndex);
      }
      return true;
    },
    mergeItems: function appStoreMergeItems(dragId, targetId) {
      var dragLoc = this.locateItem(dragId); if (!dragLoc) return false;
      var dragItem = this.removeItemByLocation(dragLoc); if (!dragItem) return false;
      var targetIndex = this.desktop.items.findIndex(function findTargetIndex(i) { return i.id === targetId; });
      if (targetIndex < 0) return false;
      var targetItem = this.desktop.items[targetIndex];
      if (targetItem.type === 'folder') { targetItem.children.push(dragItem); return true; }
      var nextFolder = createFolder(generateId('folder'), '文件夹', [targetItem, dragItem]);
      this.desktop.items.splice(targetIndex, 1, nextFolder); return true;
    },
    deleteItemById: function appStoreDeleteItemById(id) {
      var loc = this.locateItem(id); if (!loc) return false;
      this.removeItemByLocation(loc); this.cleanupFolders(); return true;
    }
  };

  // ==================== 拖拽存储 ====================
  var dragStore = {
    active: false, pointerId: null, sourceType: null, sourceEl: null, itemId: null, folderId: null,
    startX: 0, startY: 0, currentX: 0, currentY: 0, ghostEl: null, lastMoveEvent: null,
    longPressTimer: null, mergeTimer: null, mergeTargetId: null, overDelete: false, contextTriggered: false,
    originSnapshot: null, swapTargetId: null, insertTarget: null, insertTimer: null, isInGap: false,
    dragOffsetX: 0, dragOffsetY: 0, placeholderEl: null, throttledMove: null, targetCache: null, targetCacheVersion: -1, deleteZoneRect: null,
    init: function dragStoreInit() { this.throttledMove = throttle(function throttledMoveWrapper(e) { this.processDragMove(e); }.bind(this), 16); },
    reset: function dragStoreReset() {
      if (this.longPressTimer) { clearTimeout(this.longPressTimer); this.longPressTimer = null; }
      if (this.mergeTimer) { clearTimeout(this.mergeTimer); this.mergeTimer = null; }
      if (this.insertTimer) { clearTimeout(this.insertTimer); this.insertTimer = null; }
      this.clearPlaceholder();
      this.active = false; this.pointerId = null; this.sourceType = null; this.sourceEl = null; this.itemId = null; this.folderId = null;
      this.lastMoveEvent = null; this.contextTriggered = false; this.originSnapshot = null; this.overDelete = false;
      this.swapTargetId = null; this.insertTarget = null; this.isInGap = false; this.dragOffsetX = 0; this.dragOffsetY = 0; this.mergeTargetId = null;
      this.targetCache = null; this.targetCacheVersion = -1; dragInteraction.clearMergeHover(); dragInteraction.setDeleteZoneHover(false); dragInteraction.forceCleanup(); edgeHoverManager.clear();
      this.deleteZoneRect = null;
    },
    showPlaceholder: function dragStoreShowPlaceholder(target) {
      this.clearPlaceholder(); if (!target || target.container === 'dock') return;
      var placeholder = document.createElement('div'); placeholder.className = 'insert-placeholder-gap';
      placeholder.innerHTML = '<div class="insert-placeholder"></div>';
      if (target.container === 'desktop') {
        var pageEl = querySelector('.page[data-page-index="' + target.pageIndex + '"]');
        if (!pageEl || pageEl.hasAttribute('data-virtual')) {
          if (appStore.desktop.items.length > VIRTUAL_SCROLL_THRESHOLD) { renderEngine.loadVirtualPage(target.pageIndex); pageEl = querySelector('.page[data-page-index="' + target.pageIndex + '"]'); }
        }
        if (pageEl) {
          var items = querySelectorAll('.app-icon[data-scope="desktop"]', pageEl);
          var pages = renderEngine.getDesktopPagesData(), pageData = pages[target.pageIndex] || [];
          var maxInsertIdx = pageData.length, insertIdx = Math.min(target.index !== undefined ? target.index : target.insertIndex !== undefined ? target.insertIndex : maxInsertIdx, maxInsertIdx);
          if (items[insertIdx]) items[insertIdx].before(placeholder); else pageEl.appendChild(placeholder);
        }
      } else if (target.container === 'folder') {
        var grid = querySelector('#folderGrid');
        if (grid) { var folderItems = querySelectorAll('.app-icon[data-scope="folder"]', grid), folderInsertIdx = Math.min(target.index !== undefined ? target.index : folderItems.length, folderItems.length); if (folderItems[folderInsertIdx]) folderItems[folderInsertIdx].before(placeholder); else grid.appendChild(placeholder); }
      }
      this.placeholderEl = placeholder;
    },
    clearPlaceholder: function dragStoreClearPlaceholder() { if (this.placeholderEl) { this.placeholderEl.remove(); } this.placeholderEl = null; },
    beginDrag: function dragStoreBeginDrag(sourceEl, sourceType, e) {
      hideContextMenu(); this.active = true; this.pointerId = e.pointerId; this.sourceType = sourceType; this.sourceEl = sourceEl; this.itemId = sourceEl.dataset.id; this.folderId = sourceEl.dataset.folderId || null;
      this.originSnapshot = { desktop: deepClone(appStore.desktop.items), dock: deepClone(appStore.dock.items), currentPage: appStore.currentPage, folderModalId: appStore.folderModalId };
      var rect = sourceEl.getBoundingClientRect(); this.dragOffsetX = e.clientX - rect.left; this.dragOffsetY = e.clientY - rect.top; this.startX = e.clientX; this.startY = e.clientY;
      sourceEl.classList.add('drag-source'); this.ghostEl = dragInteraction.createGhost(sourceEl); dragInteraction.updateGhostPosition(e.clientX, e.clientY); dragInteraction.setDeleteZoneVisible(true);
      if (sourceType === 'folder') closeFolder();
    },
    processDragMove: function dragStoreProcessDragMove(e) {
      if (!this.active) return; this.lastMoveEvent = e; this.currentX = e.clientX; this.currentY = e.clientY;
      dragInteraction.updateGhostPosition(e.clientX, e.clientY);
      var target = this.detectDropTargetOptimized(e.clientX, e.clientY, this.itemId);
      if (target.type === 'delete') { dragInteraction.setDeleteZoneHover(true); this.clearMergeCandidate(); this.clearSwapHover(); dragInteraction.clearMergeHover(); this.isInGap = false; this.clearPlaceholder(); return; }
      else dragInteraction.setDeleteZoneHover(false);
      if (target.type === 'icon' && target.container === 'desktop' && target.targetId) {
        var dragItem = appStore.getItemById(this.itemId);
        if (dragItem && dragItem.type !== 'folder' && this.canMerge(this.itemId, target.targetId)) this.queueMergeTarget(target.targetId);
      } else if (!this.mergeTargetId) this.clearMergeCandidate();
      if (target.type === 'icon' && target.targetId && target.targetId !== this.itemId) {
        this.clearPlaceholder(); this.clearSwapHover();
        if (!this.mergeTargetId) { var targetEl = target.target; if (targetEl) { targetEl.classList.add('exchange-target'); this.swapTargetId = target.targetId; } }
        this.isInGap = false;
      } else if (target.type === 'gap') {
        this.clearSwapHover(); dragInteraction.clearMergeHover();
        if (!this.isInGap || !this.insertTarget || this.insertTarget.container !== target.container || this.insertTarget.index !== target.index || (target.container === 'desktop' && this.insertTarget.pageIndex !== target.pageIndex)) {
          var currentLoc = appStore.locateItem(this.itemId);
          this.insertTarget = { container: target.container, index: target.index, pageIndex: target.pageIndex, globalIndex: target.globalIndex, folderId: target.folderId, sourceScope: currentLoc && currentLoc.scope, sourceGlobalIndex: currentLoc && currentLoc.globalIndex, sourceIndex: currentLoc && currentLoc.index };
          this.isInGap = true; this.showPlaceholder(this.insertTarget);
          var self = this; if (this.insertTimer) clearTimeout(this.insertTimer);
          this.insertTimer = setTimeout(function insertTimerCallback() {
            if (self.isInGap && self.insertTarget) {
              renderEngine.updateWithAnimation(function insertAnimationCallback() {
                var loc = appStore.locateItem(self.itemId), adjustedTarget = Object.assign({}, self.insertTarget);
                if (loc) {
                  var isCrossContainer = loc.scope !== adjustedTarget.container;
                  if (!isCrossContainer && loc.scope === adjustedTarget.container) {
                    if (loc.scope === 'desktop' && adjustedTarget.globalIndex > loc.globalIndex) { adjustedTarget.globalIndex--; adjustedTarget.index--; }
                    else if ((loc.scope === 'dock' || loc.scope === 'folder') && adjustedTarget.index > loc.index) { adjustedTarget.index--; }
                  }
                }
                appStore.insertItemAt(self.itemId, adjustedTarget);
                self.sourceEl = document.querySelector('.app-icon[data-id="' + CSS.escape(self.itemId) + '"]');
                if (self.sourceEl) self.sourceEl.classList.add('drag-source');
                var newLoc = appStore.locateItem(self.itemId);
                if (newLoc) self.showPlaceholder({ container: newLoc.scope, index: (newLoc.globalIndex !== undefined ? newLoc.globalIndex : newLoc.index) + 1, pageIndex: newLoc.pageIndex, folderId: newLoc.folderId });
              });
            }
          }, 200);
        }
      } else { this.clearSwapHover(); this.clearPlaceholder(); this.isInGap = false; if (this.insertTimer) { clearTimeout(this.insertTimer); this.insertTimer = null; } }
      edgeHoverManager.check(e.clientX, e.clientY, this.startX, this.startY);
    },
    detectDropTargetOptimized: function dragStoreDetectDropTargetOptimized(x, y, excludeId) {
      var deleteZone = querySelector('#deleteZone');
      if (deleteZone) {
        if (deleteZone.classList.contains('active')) {
          this.deleteZoneRect = deleteZone.getBoundingClientRect();
        } else if (!this.deleteZoneRect) {
          this.deleteZoneRect = deleteZone.getBoundingClientRect();
        }
        var r = this.deleteZoneRect;
        var tolerance = 20;
        if (x >= r.left - tolerance && x <= r.right + tolerance && y >= r.top - tolerance && y <= r.bottom + tolerance) return { type: 'delete', target: null, insertIndex: -1, container: null };
      }
      var m = layoutStore.metrics, pages = querySelectorAll('.page');
      for (var p = 0; p < pages.length; p++) {
        var page = pages[p], pageIndex = Number(page.dataset.pageIndex), pageRect = page.getBoundingClientRect();
        if (x >= pageRect.left && x <= pageRect.right && y >= pageRect.top && y <= pageRect.bottom) {
          var slots = layoutStore.virtualGridCache[pageIndex];
          if (!slots || slots.length === 0) { slots = layoutStore.calcVirtualGrid(pageIndex); layoutStore.virtualGridCache[pageIndex] = slots; }
          var cacheKey = 'page_' + pageIndex + '_' + layoutStore.gridVersion;
          if (!this.targetCache || this.targetCacheVersion !== layoutStore.gridVersion) { this.targetCache = new Map(); this.targetCacheVersion = layoutStore.gridVersion; }
          var iconPositions = this.targetCache.get(cacheKey);
          if (!iconPositions) {
            iconPositions = []; var pageItems = querySelectorAll('.app-icon[data-scope="desktop"]', page);
            for (var i = 0; i < pageItems.length; i++) { var icon = pageItems[i]; if (icon.dataset.id === excludeId) continue; var rect = icon.getBoundingClientRect(); iconPositions.push({ el: icon, id: icon.dataset.id, left: rect.left - 10, right: rect.right + 10, top: rect.top - 10, bottom: rect.bottom + 10, cx: rect.left + rect.width / 2, cy: rect.top + rect.height / 2 }); }
            this.targetCache.set(cacheKey, iconPositions);
          }
          for (var j = 0; j < iconPositions.length; j++) {
            var iconPos = iconPositions[j];
            if (x >= iconPos.left && x <= iconPos.right && y >= iconPos.top && y <= iconPos.bottom) return { type: 'icon', target: iconPos.el, targetId: iconPos.id, insertIndex: -1, container: 'desktop', pageIndex: pageIndex };
          }
          var relX = x - (pageRect.left + m.pagePaddingX), relY = y - (pageRect.top + 8);
          var col = Math.floor(relX / (m.cellWidth + m.colGap)), row = Math.floor(relY / (m.cellHeight + m.rowGap));
          var pagesData = renderEngine.getDesktopPagesData(), pageItemsData = pagesData[pageIndex] || [], maxInsertIndex = pageItemsData.length, insertIndex = clamp(row * m.columns + col, 0, maxInsertIndex);
          var inGap = true, iconHalfWidth = m.iconSize * 0.5, iconHalfHeight = m.cellHeight * 0.5, gapThreshold = m.colGap * 0.3;
          for (var k = 0; k < iconPositions.length; k++) { var pos = iconPositions[k], dxToCenter = x - pos.cx, dyToCenter = y - pos.cy, inIconX = Math.abs(dxToCenter) < (iconHalfWidth + gapThreshold), inIconY = Math.abs(dyToCenter) < (iconHalfHeight + gapThreshold); if (inIconX && inIconY) { inGap = false; break; } }
          return { type: inGap ? 'gap' : 'icon', target: null, targetId: null, insertIndex: insertIndex, container: 'desktop', pageIndex: pageIndex, globalIndex: pageIndex * m.pageCapacity + insertIndex };
        }
      }
      var dock = querySelector('#dock');
      if (dock) {
        var dockRect = dock.getBoundingClientRect();
        if (x >= dockRect.left && x <= dockRect.right && y >= dockRect.top && y <= dockRect.bottom) {
          var dockItems = querySelectorAll('.app-icon[data-scope="dock"]'), slotWidth = dockRect.width / Math.max(1, appStore.dock.capacity), relativeX = x - dockRect.left, dockInsertIndex = clamp(Math.floor(relativeX / slotWidth), 0, appStore.dock.items.length);
          for (var d = 0; d < dockItems.length; d++) { var dockIcon = dockItems[d]; if (dockIcon.dataset.id === excludeId) continue; var dockIconRect = dockIcon.getBoundingClientRect(); if (x >= dockIconRect.left && x <= dockIconRect.right && y >= dockIconRect.top && y <= dockIconRect.bottom) return { type: 'icon', target: dockIcon, targetId: dockIcon.dataset.id, insertIndex: -1, container: 'dock', index: Number(dockIcon.dataset.localIndex) }; }
          return { type: 'gap', target: null, targetId: null, insertIndex: dockInsertIndex, container: 'dock', index: dockInsertIndex };
        }
      }
      if (appStore.folderModalId) {
        var grid = querySelector('#folderGrid');
        if (grid) {
          var gridRect = grid.getBoundingClientRect();
          if (x >= gridRect.left && x <= gridRect.right && y >= gridRect.top && y <= gridRect.bottom) {
            var folderItems = querySelectorAll('.app-icon[data-scope="folder"]'), folderItemWidth = gridRect.width / 3, relXFolder = x - gridRect.left, relYFolder = y - gridRect.top, folderCol = Math.floor(relXFolder / folderItemWidth), folderRow = Math.floor(relYFolder / 100), folderInsertIndex = clamp(folderRow * 3 + folderCol, 0, folderItems.length);
            for (var f = 0; f < folderItems.length; f++) { var folderIcon = folderItems[f]; if (folderIcon.dataset.id === excludeId) continue; var folderIconRect = folderIcon.getBoundingClientRect(); if (x >= folderIconRect.left && x <= folderIconRect.right && y >= folderIconRect.top && y <= folderIconRect.bottom) return { type: 'icon', target: folderIcon, targetId: folderIcon.dataset.id, insertIndex: -1, container: 'folder', folderId: appStore.folderModalId, index: Number(folderIcon.dataset.childIndex) }; }
            return { type: 'gap', target: null, targetId: null, insertIndex: folderInsertIndex, container: 'folder', folderId: appStore.folderModalId, index: folderInsertIndex };
          }
        }
      }
      return { type: 'none', target: null, insertIndex: -1, container: null };
    },
    canMerge: function dragStoreCanMerge(dragId, targetId) {
      if (!dragId || !targetId || dragId === targetId) return false;
      var dragItem = appStore.getItemById(dragId), targetItem = appStore.getItemById(targetId);
      if (!dragItem || !targetItem) return false;
      if (dragItem.type === 'folder') return false;
      var dockIndex = appStore.dock.items.findIndex(function findDockMergeIndex(i) { return i.id === targetId; });
      if (dockIndex >= 0) return false;
      return targetItem.type === 'app' || targetItem.type === 'folder';
    },
    queueMergeTarget: function dragStoreQueueMergeTarget(targetId) {
      if (this.mergeTargetId === targetId) return; this.clearMergeCandidate();
      var self = this;
      this.mergeTimer = setTimeout(function mergeTimerCallback() {
        self.mergeTargetId = targetId; var targetEl = document.querySelector('.page .app-icon[data-id="' + CSS.escape(targetId) + '"]');
        if (targetEl) targetEl.classList.add('merge-hover');
      }, 220);
    },
    clearMergeCandidate: function dragStoreClearMergeCandidate() { if (this.mergeTimer) { clearTimeout(this.mergeTimer); this.mergeTimer = null; } this.mergeTargetId = null; dragInteraction.clearMergeHover(); },
    clearSwapHover: function dragStoreClearSwapHover() { querySelectorAll('.exchange-target').forEach(function clearSwapHoverEach(el) { el.classList.remove('exchange-target'); }); this.swapTargetId = null; },
    handlePointerUp: function dragStoreHandlePointerUp(e) {
      if (this.longPressTimer) { clearTimeout(this.longPressTimer); this.longPressTimer = null; }
      edgeHoverManager.clear();
      if (!this.active) { this.reset(); return; }
      e.preventDefault();
      if (this.overDelete) { var self = this; renderEngine.updateWithAnimation(function deleteAnimationCallback() { appStore.deleteItemById(self.itemId); appStore.cleanupFolders(); }); if (this.sourceType === 'folder') renderEngine.renderFolderModal(); showToast('已删除'); this.reset(); return; }
      if (this.mergeTargetId) { var self = this; renderEngine.updateWithAnimation(function mergeAnimationCallback() { appStore.mergeItems(self.itemId, self.mergeTargetId); appStore.cleanupFolders(); }); this.reset(); return; }
      if (this.swapTargetId && this.swapTargetId !== this.itemId) { var self = this; renderEngine.updateWithAnimation(function swapAnimationCallback() { appStore.swapItems(self.itemId, self.swapTargetId); }); this.reset(); return; }
      if (this.isInGap && this.insertTarget) { this.reset(); return; }
      if (this.originSnapshot) { appStore.desktop.items = deepClone(this.originSnapshot.desktop); appStore.dock.items = deepClone(this.originSnapshot.dock); appStore.currentPage = this.originSnapshot.currentPage; appStore.folderModalId = this.originSnapshot.folderModalId; renderEngine.renderAll(); }
      this.reset();
    },
    handlePointerDown: function dragStoreHandlePointerDown(e) {
      if (e.target.closest('.context-menu') || e.target.closest('.form-content') || e.target.closest('.folder-content .top-btn') || e.target.closest('.search-screen') || e.target.closest('.engine-form-modal') || e.target.closest('.sync-modal')) return;
      hideContextMenu();
      var iconEl = e.target.closest('.app-icon[data-id]'), isFormControl = !!e.target.closest('input, textarea, button, label');
      if (isFormControl) return; this.pointerId = e.pointerId; this.startX = e.clientX; this.startY = e.clientY; this.contextTriggered = false;
      var deleteZone = querySelector('#deleteZone'); if (deleteZone) this.deleteZoneRect = deleteZone.getBoundingClientRect();
      var self = this;
      if (iconEl) { this.sourceEl = iconEl; this.longPressTimer = setTimeout(function longPressTimerCallback() { if (self.active) return; self.contextTriggered = true; showContextMenu(e.clientX, e.clientY, getContextTargetFromElement(iconEl)); }, LONG_PRESS_DURATION); return; }
      var onDesktopBlank = e.target.closest('.desktop') && !e.target.closest('.app-icon');
      if (onDesktopBlank) this.longPressTimer = setTimeout(function desktopBlankLongPressCallback() { self.contextTriggered = true; showContextMenu(e.clientX, e.clientY, { kind: 'blank', scope: 'desktop-blank' }); }, LONG_PRESS_DURATION);
    },
    handlePointerMove: function dragStoreHandlePointerMove(e) {
      if (this.pointerId !== e.pointerId) return;
      var dx = e.clientX - this.startX, dy = e.clientY - this.startY, movedEnough = Math.hypot(dx, dy) > 8;
      if (!this.active && movedEnough && this.sourceEl && !this.contextTriggered) { if (this.longPressTimer) { clearTimeout(this.longPressTimer); this.longPressTimer = null; } var sourceType = this.sourceEl.dataset.scope === 'folder' ? 'folder' : this.sourceEl.dataset.scope; this.beginDrag(this.sourceEl, sourceType, e); }
      if (!this.active) return; e.preventDefault(); this.throttledMove(e);
    }
  };

  var edgeHoverManager = { 
    isHovering: false, direction: null, timer: null, startX: 0, startY: 0, 
    check: function edgeHoverManagerCheck(clientX, clientY, dragStartX, dragStartY) { 
      var edgeWidth = 40, vw = window.innerWidth, pageCount = appStore.getPageCount(); 
      if (pageCount <= 1) { this.clear(); return; } 
      var isLeftEdge = clientX < edgeWidth && appStore.currentPage > 0, isRightEdge = clientX > vw - edgeWidth && appStore.currentPage < pageCount - 1, dx = Math.abs(clientX - dragStartX), dy = Math.abs(clientY - dragStartY), angleValid = dy === 0 || (dx / dy) > 0.5, direction = isLeftEdge ? 'left' : isRightEdge ? 'right' : null, self = this; 
      if (direction && angleValid) { 
        if (!this.isHovering || this.direction !== direction) { 
          this.clear(); this.isHovering = true; this.direction = direction; 
          this.timer = setTimeout(function edgeHoverTimerCallback() { 
            if (direction === 'left' && appStore.currentPage > 0) pageManager.turnTo(appStore.currentPage - 1); 
            else if (direction === 'right' && appStore.currentPage < pageCount - 1) pageManager.turnTo(appStore.currentPage + 1); 
            self.clear(); 
          }, 300); 
        } 
      } else this.clear(); 
    }, 
    clear: function edgeHoverManagerClear() { this.isHovering = false; this.direction = null; if (this.timer) { clearTimeout(this.timer); this.timer = null; } } 
  };

  // ==================== 搜索存储 ====================
  var searchStore = {
    engines: PRESET_ENGINES.slice(), currentEngine: PRESET_ENGINES[2], suggestTimer: null, suggestions: [], searchScreenLock: false,
    loadCustomEngines: function searchStoreLoadCustomEngines() {
      var self = this;
      return storageAdapter.getItem(STORAGE_KEYS.CUSTOM_ENGINES).then(function loadCustomEnginesThen(saved) {
        if (saved) {
          try {
            var customEngines = JSON.parse(saved);
            if (Array.isArray(customEngines)) self.engines = PRESET_ENGINES.concat(customEngines);
          } catch (e) {}
        }
      }).catch(function loadCustomEnginesCatch() {});
    },
    saveCustomEngines: function searchStoreSaveCustomEngines() { 
      var customEngines = this.engines.filter(function filterCustomEngines(e) { return !e.id.startsWith('preset-'); }); 
      storageAdapter.setItem(STORAGE_KEYS.CUSTOM_ENGINES, JSON.stringify(customEngines)); 
    },
    addCustomEngine: function searchStoreAddCustomEngine(name, icon, url) { 
      var newEngine = { id: generateId('engine'), name: name, icon: icon || 'mdi:magnify', url: url.indexOf('%s') > -1 ? url : url + '%s' }; 
      this.engines.push(newEngine); this.saveCustomEngines(); return newEngine; 
    },
    deleteCustomEngine: function searchStoreDeleteCustomEngine(engineId) { 
      var index = this.engines.findIndex(function findEngineIndex(e) { return e.id === engineId; }); 
      if (index > -1 && !engineId.startsWith('preset-')) { 
        this.engines.splice(index, 1); this.saveCustomEngines(); 
        if (this.currentEngine.id === engineId) { this.currentEngine = this.engines[2]; this.syncIcons(); } 
        return true; 
      } return false; 
    },
    syncIcons: function searchStoreSyncIcons() {
      var currentIcon = this.currentEngine && this.currentEngine.icon ? this.currentEngine.icon : 'mdi:magnify';
      var iconEl = document.getElementById('engineIcon'), searchIconEl = document.getElementById('searchScreenEngineIcon');
      function setElClass(el, cls) {
        if (!el) return;
        if (el.tagName && el.tagName.toLowerCase() === 'svg') {
          el.setAttribute('class', cls);
        } else {
          el.className = cls;
        }
      }
      function applyEngineIconToEl(el, icon) {
        if (!el) return;
        var parent = el.parentElement;
        var id = el.id;
        if (isImageIcon(icon)) {
          var wrapper;
          if (el.tagName && el.tagName.toLowerCase() === 'svg') {
            wrapper = document.createElement('span');
            wrapper.id = id;
            wrapper.setAttribute('tabindex', el.getAttribute('tabindex') || '0');
            wrapper.setAttribute('role', el.getAttribute('role') || 'button');
            wrapper.setAttribute('aria-label', el.getAttribute('aria-label') || '');
            parent.replaceChild(wrapper, el);
          } else {
            wrapper = el;
          }
          wrapper.className = 'search-icon engine-img-wrap';
          wrapper.removeAttribute('data-icon');
          wrapper.innerHTML = '';
          var img = document.createElement('img');
          img.src = icon;
          img.alt = '';
          img.setAttribute('draggable', 'false');
          wrapper.appendChild(img);
        } else {
          var target;
          if (el.tagName && el.tagName.toLowerCase() === 'svg') {
            target = document.createElement('span');
            target.id = id;
            target.setAttribute('tabindex', el.getAttribute('tabindex') || '0');
            target.setAttribute('role', el.getAttribute('role') || 'button');
            target.setAttribute('aria-label', el.getAttribute('aria-label') || '');
            parent.replaceChild(target, el);
          } else {
            target = el;
          }
          target.className = 'search-icon iconify';
          target.setAttribute('data-icon', icon);
          target.innerHTML = '';
          if (window.Iconify) { try { Iconify.scan(target); } catch (_) {} }
        }
      }
      requestAnimationFrame(function syncIconsRAF() {
        applyEngineIconToEl(iconEl, currentIcon);
        applyEngineIconToEl(searchIconEl, currentIcon);
      });
    },
    getHistory: function searchStoreGetHistory() { 
      return storageAdapter.getItem(STORAGE_KEYS.SEARCH_HISTORY).then(function getHistoryThen(saved) { return saved ? JSON.parse(saved) : []; }).catch(function getHistoryCatch() { return []; }); 
    },
    addHistory: function searchStoreAddHistory(keyword) { 
      this.getHistory().then(function addHistoryThen(history) { 
        if (!keyword || keyword.trim().length === 0) return; 
        var trimmed = keyword.trim(), filtered = history.filter(function historyFilter(h) { return h !== trimmed; }); 
        filtered.unshift(trimmed); 
        storageAdapter.setItem(STORAGE_KEYS.SEARCH_HISTORY, JSON.stringify(filtered.slice(0, 20))); 
      }); 
    },
    removeHistoryItem: function searchStoreRemoveHistoryItem(keyword) {
      var self = this;
      this.searchScreenLock = true;
      return this.getHistory().then(function removeHistoryItemThen(history) {
        var filtered = history.filter(function historyFilter(h) { return h !== keyword; });
        return storageAdapter.setItem(STORAGE_KEYS.SEARCH_HISTORY, JSON.stringify(filtered)).then(function removeHistoryItemSaveThen() {
          var val = refs.searchScreenInput ? refs.searchScreenInput.value.trim() : '';
          if (val) fetchSearchSuggestions(val);
          else renderSuggestionsToBody([]);
          setTimeout(function removeHistoryItemUnlock() { self.searchScreenLock = false; }, 300);
        });
      });
    },
    clearHistory: function searchStoreClearHistory() { 
      var self = this; 
      this.searchScreenLock = true;
      storageAdapter.removeItem(STORAGE_KEYS.SEARCH_HISTORY).then(function clearHistoryThen() { 
        self.suggestions = []; 
        var body = refs.searchScreenBody; 
        if (body) body.innerHTML = '<div class="suggest-empty">输入关键词查看搜索建议</div>'; 
        setTimeout(function clearHistoryUnlock() { self.searchScreenLock = false; }, 300);
      }); 
    }
  };

  // ==================== 增强的 GitHub 同步模块 ====================
  var syncStore = {
    config: { token: '', owner: '', repo: '', syncInterval: 0, lastSyncTime: null, fileName: 'desktop_backup.json' },
    autoSyncTimer: null,
    AUTO_SYNC_CHECK_INTERVAL: 60 * 1000,
    load: function syncStoreLoad() { 
      var self = this; 
      storageAdapter.getItem(STORAGE_KEYS.GITHUB_CONFIG).then(function syncStoreLoadThen(saved) { 
        if (saved) { 
          try { 
            var data = JSON.parse(saved); 
            Object.assign(self.config, data); 
          } catch (e) {} 
        } 
        updateSyncTimeInfo(); 
        self.startAutoSync(); 
      }).catch(function syncStoreLoadCatch() { self.startAutoSync(); }); 
    },
    save: function syncStoreSave() { 
      storageAdapter.setItem(STORAGE_KEYS.GITHUB_CONFIG, JSON.stringify(this.config)); 
    },
    startAutoSync: function syncStoreStartAutoSync() {
      var self = this;
      if (self.autoSyncTimer) {
        clearInterval(self.autoSyncTimer);
        self.autoSyncTimer = null;
      }
      if (self.config.syncInterval > 0 && self.config.token && self.config.owner && self.config.repo) {
        self.autoSyncTimer = setInterval(function autoSyncIntervalCallback() {
          self.checkAndPerformAutoSync();
        }, self.AUTO_SYNC_CHECK_INTERVAL);
      }
    },
    stopAutoSync: function syncStoreStopAutoSync() {
      if (this.autoSyncTimer) {
        clearInterval(this.autoSyncTimer);
        this.autoSyncTimer = null;
      }
    },
    checkAndPerformAutoSync: function syncStoreCheckAndPerformAutoSync() {
      var self = this;
      if (!self.config.syncInterval || self.config.syncInterval <= 0) return;
      if (!self.config.lastSyncTime) {
        self.performAutoSync();
        return;
      }
      var lastSync = new Date(self.config.lastSyncTime);
      var now = new Date();
      var daysSinceLastSync = (now - lastSync) / (1000 * 60 * 60 * 24);
      if (daysSinceLastSync >= self.config.syncInterval) {
        self.performAutoSync();
      }
    },
    performAutoSync: function syncStorePerformAutoSync() {
      var self = this;
      if (!self.config.token || !self.config.owner || !self.config.repo) return;
      self.push(false).then(function autoSyncPushThen(success) {
        if (success) {
          showToast('✅ 自动同步成功');
        }
        updateSyncTimeInfo();
      });
    },
    updateSyncInterval: function syncStoreUpdateSyncInterval(interval) {
      this.config.syncInterval = interval;
      this.save();
      this.stopAutoSync();
      this.startAutoSync();
      updateSyncTimeInfo();
    },
    validateToken: function syncStoreValidateToken(token) {
      if (!token) return Promise.resolve(null);
      var self = this;
      return fetch('https://api.github.com/user', { 
        headers: { 'Authorization': 'token ' + token } 
      }).then(function validateTokenThen(res) { 
        if (!res.ok) throw new Error('Token无效'); 
        return res.json(); 
      }).then(function validateTokenJson(user) { 
        self.config.token = token; 
        self.config.owner = user.login; 
        self.save(); 
        showToast('验证成功: ' + user.login); 
        return user.login; 
      }).catch(function validateTokenCatch(err) { 
        showToast('❌ ' + err.message); 
        return null; 
      });
    },
    push: function syncStorePush(showToastMsg) {
      var self = this;
      if (!self.config.token || !self.config.owner) { 
        if (showToastMsg) showToast('请先配置 GitHub Token'); 
        return Promise.resolve(false); 
      }
      if (!self.config.repo) { 
        if (showToastMsg) showToast('请先填写仓库名称'); 
        return Promise.resolve(false); 
      }
      var syncData = { 
            desktop: appStore.desktop, 
            dock: appStore.dock, 
            currentQuote: appStore.currentQuote, 
            currentEngineId: searchStore.currentEngine ? searchStore.currentEngine.id : null, 
            customEngines: searchStore.engines.filter(function filterPushEngines(e) { return !e.id.startsWith('preset-'); }), 
            timestamp: new Date().toISOString(), 
            version: '2.0' 
          },
          content = JSON.stringify(syncData, null, 2),
          base64Content, 
          fileName = self.config.fileName,
          apiUrl = 'https://api.github.com/repos/' + self.config.owner + '/' + self.config.repo + '/contents/' + fileName;

      try {
        base64Content = btoa(unescape(encodeURIComponent(content)));
      } catch (e) {
        showToast('❌ 数据编码失败');
        return Promise.resolve(false);
      }

      return fetch(apiUrl, { 
        headers: { 
          'Authorization': 'token ' + self.config.token, 
          'Accept': 'application/vnd.github.v3+json' 
        } 
      }).then(function pushGetThen(res) { 
        if (res.ok) return res.json(); 
        return null; 
      }).then(function pushGetJson(fileData) {
        var body = { 
          message: 'Update desktop data - ' + new Date().toLocaleString('zh-CN'), 
          content: base64Content 
        };
        if (fileData && fileData.sha) body.sha = fileData.sha;
        return fetch(apiUrl, { 
          method: 'PUT', 
          headers: { 
            'Authorization': 'token ' + self.config.token, 
            'Accept': 'application/vnd.github.v3+json', 
            'Content-Type': 'application/json' 
          }, 
          body: JSON.stringify(body) 
        });
      }).then(function pushPutThen(res) { 
        if (!res.ok) {
          return res.json().then(function pushPutJsonErr(err) { 
            throw new Error(err.message || '上传失败 (HTTP ' + res.status + ')'); 
          }).catch(function pushPutCatchErr(parseErr) {
            if (parseErr.message && parseErr.message.indexOf('HTTP') > -1) throw parseErr;
            throw new Error('上传失败 (HTTP ' + res.status + ')');
          });
        }
        self.config.lastSyncTime = Date.now(); 
        self.save(); 
        if (showToastMsg) showToast('✅ 已成功上传到 GitHub'); 
        updateSyncTimeInfo();
        return true; 
      }).catch(function pushCatchErr(err) { 
        var msg = err && err.message ? err.message : '网络错误或CSP限制';
        showToast('❌ 上传失败: ' + msg); 
        return false; 
      });
    },
    pull: function syncStorePull() {
      if (!this.config.token || !this.config.owner) { 
        showToast('请先配置 GitHub Token'); 
        return Promise.resolve(false); 
      }
      if (!this.config.repo) { 
        showToast('请先填写仓库名称'); 
        return Promise.resolve(false); 
      }
      var self = this, 
          fileName = this.config.fileName,
          apiUrl = 'https://api.github.com/repos/' + this.config.owner + '/' + this.config.repo + '/contents/' + fileName;

      return fetch(apiUrl, { 
        headers: { 
          'Authorization': 'token ' + self.config.token, 
          'Accept': 'application/vnd.github.v3+json' 
        } 
      }).then(function pullThen(res) { 
        if (!res.ok) { 
          if (res.status === 404) { 
            showToast('⚠️ 云端暂无备份数据'); 
            return false; 
          } 
          return res.json().then(function pullJsonErr(err) { 
            throw new Error(err.message || '获取失败 (HTTP ' + res.status + ')'); 
          }).catch(function pullCatchErr(parseErr) {
            if (parseErr.message && parseErr.message.indexOf('HTTP') > -1) throw parseErr;
            throw new Error('获取失败 (HTTP ' + res.status + ')');
          });
        } 
        return res.json(); 
      }).then(function pullJson(fileData) { 
        if (!fileData) return false; 
        var content, syncData;
        try {
          content = decodeURIComponent(escape(atob(fileData.content)));
          syncData = JSON.parse(content);
        } catch (e) {
          showToast('❌ 数据解析失败');
          return false;
        }
        if (syncData.desktop) appStore.desktop = syncData.desktop; 
        if (syncData.dock) appStore.dock = syncData.dock; 
        if (syncData.currentQuote) appStore.currentQuote = syncData.currentQuote; 
        if (syncData.customEngines && Array.isArray(syncData.customEngines)) { 
          searchStore.engines = PRESET_ENGINES.concat(syncData.customEngines); 
          searchStore.saveCustomEngines(); 
        } 
        if (syncData.currentEngineId) { 
          var savedEngine = searchStore.engines.find(function findPullEngine(e) { return e.id === syncData.currentEngineId; }); 
          if (savedEngine) { 
            searchStore.currentEngine = savedEngine; 
            searchStore.syncIcons(); 
          } 
        } 
        self.config.lastSyncTime = Date.now(); 
        self.save(); 
        appStore.save(); 
        renderEngine.renderAll(); 
        showToast('✅ 已成功从 GitHub 恢复数据'); 
        updateSyncTimeInfo();
        return true; 
      }).catch(function pullCatchErr(err) { 
        var msg = err && err.message ? err.message : '网络错误或CSP限制';
        showToast('❌ 恢复失败: ' + msg); 
        return false; 
      });
    }
  };

  // ==================== 渲染引擎 ====================
  var renderEngine = {
    prevRects: null, flipAnimations: new WeakMap(),
    captureRects: function renderEngineCaptureRects() {
      var map = new Map();
      querySelectorAll('.app-icon[data-id]').forEach(function captureRectsEach(el) { var rect = el.getBoundingClientRect(); map.set(el.dataset.id, { left: rect.left, top: rect.top, width: rect.width, height: rect.height }); });
      return map;
    },
    playFLIP: function renderEnginePlayFLIP() {
      if (!this.prevRects) return; var self = this;
      querySelectorAll('.app-icon[data-id]').forEach(function playFLIPEach(el) {
        var id = el.dataset.id, prev = self.prevRects.get(id); if (!prev) return;
        var next = el.getBoundingClientRect(), dx = prev.left - next.left, dy = prev.top - next.top;
        if (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5) {
          var prevAnim = self.flipAnimations.get(el); if (prevAnim) { cancelAnimationFrame(prevAnim.rafId); clearTimeout(prevAnim.timeoutId); }
          el.style.transition = 'none'; el.style.transform = 'translate3d(' + dx + 'px, ' + dy + 'px, 0)'; el.offsetHeight;
          var rafId = requestAnimationFrame(function playFLIPRAF() {
            el.style.transition = 'transform 230ms cubic-bezier(.2,.8,.2,1)'; el.style.transform = 'translate3d(0, 0, 0)';
            var timeoutId = setTimeout(function cleanupFLIP() { el.style.transition = ''; el.style.transform = ''; self.flipAnimations.delete(el); }, 250);
            self.flipAnimations.set(el, { rafId: null, timeoutId: timeoutId });
          });
          self.flipAnimations.set(el, { rafId: rafId, timeoutId: null });
        }
      });
      this.prevRects = null;
    },
    cleanupFLIP: function renderEngineCleanupFLIP() { 
      var self = this; 
      querySelectorAll('.app-icon[data-id]').forEach(function cleanupFLIPEach(el) { 
        var anim = self.flipAnimations.get(el); 
        if (anim) { if (anim.rafId) cancelAnimationFrame(anim.rafId); if (anim.timeoutId) clearTimeout(anim.timeoutId); el.style.transition = ''; el.style.transform = ''; } 
      }); 
      this.flipAnimations = new WeakMap(); 
    },
    updateWithAnimation: function renderEngineUpdateWithAnimation(mutator) { this.prevRects = this.captureRects(); mutator(); this.renderAll(); var self = this; requestAnimationFrame(function updateWithAnimationRAF() { self.playFLIP(); }); },
    renderAll: function renderEngineRenderAll() { 
      appStore.cleanupFolders(); appStore.clampCurrentPage(); this.renderPages(); this.renderDock(); this.renderFolderModal(); 
      dragInteraction.clearMergeHover(); dragStore.clearSwapHover(); 
      if (window.Iconify) { try { Iconify.scan(document.body); } catch (_) {} } 
      appStore.save(); 
    },
    getDesktopPagesData: function renderEngineGetDesktopPagesData() { 
      var pages = [], cap = layoutStore.metrics ? layoutStore.metrics.pageCapacity : 20; 
      for (var i = 0; i < appStore.desktop.items.length; i += cap) pages.push(appStore.desktop.items.slice(i, i + cap)); 
      if (!pages.length) pages.push([]); 
      return pages; 
    },
    renderPages: function renderEngineRenderPages() {
      var pages = this.getDesktopPagesData(), totalItems = appStore.desktop.items.length, useVirtualScroll = totalItems > VIRTUAL_SCROLL_THRESHOLD;
      if (useVirtualScroll) this.renderPagesVirtual(pages); else this.renderPagesNormal(pages);
      this.renderIndicators(); pageManager.updateTransform(false);
      var self = this; if (window.requestIdleCallback) requestIdleCallback(function renderPagesIdleCallback() { layoutStore.precomputeAllGrids(); }, { timeout: 100 }); else layoutStore.precomputeAllGrids();
    },
    renderPagesNormal: function renderEngineRenderPagesNormal(pages) { 
      var self = this; 
      refs.pagesContainer.innerHTML = pages.map(function renderPagesNormalMap(items, pageIndex) { 
        return '<div class="page" data-page-index="' + pageIndex + '">' + items.map(function renderPagesNormalItemMap(item, localIndex) { return self.renderDesktopItem(item, pageIndex, localIndex); }).join('') + '</div>'; 
      }).join(''); 
    },
    renderPagesVirtual: function renderEngineRenderPagesVirtual(pages) {
      var currentPage = appStore.currentPage, renderRange = { start: Math.max(0, currentPage - 1), end: Math.min(pages.length - 1, currentPage + 1) }, self = this;
      refs.pagesContainer.innerHTML = pages.map(function renderPagesVirtualMap(items, pageIndex) {
        var isVisible = pageIndex >= renderRange.start && pageIndex <= renderRange.end;
        if (!isVisible) return '<div class="page ' + self.getPageClass(pageIndex, currentPage) + '" data-page-index="' + pageIndex + '" data-virtual="true">' + self.renderPagePlaceholder(items.length) + '</div>';
        return '<div class="page ' + self.getPageClass(pageIndex, currentPage) + '" data-page-index="' + pageIndex + '">' + items.map(function renderPagesVirtualItemMap(item, localIndex) { return self.renderDesktopItem(item, pageIndex, localIndex); }).join('') + '</div>';
      }).join('');
    },
    getPageClass: function renderEngineGetPageClass(pageIndex, currentPage) { if (pageIndex === currentPage) return 'page-current'; if (pageIndex === currentPage - 1) return 'page-prev'; if (pageIndex === currentPage + 1) return 'page-next'; return ''; },
    renderPagePlaceholder: function renderEngineRenderPagePlaceholder(itemCount) { 
      var m = layoutStore.metrics, rows = Math.ceil(itemCount / m.columns), height = rows * (m.cellHeight + m.rowGap); 
      return '<div class="virtual-scroll-spacer" style="--spacer-height: ' + height + 'px;"></div>'; 
    },
    loadVirtualPage: function renderEngineLoadVirtualPage(pageIndex) {
      var pageEl = querySelector('.page[data-page-index="' + pageIndex + '"][data-virtual="true"]');
      if (!pageEl) return;
      var cap = layoutStore.metrics ? layoutStore.metrics.pageCapacity : 20, startIndex = pageIndex * cap, items = appStore.desktop.items.slice(startIndex, startIndex + cap), self = this;
      pageEl.innerHTML = items.map(function loadVirtualPageMap(item, localIndex) { return self.renderDesktopItem(item, pageIndex, localIndex); }).join('');
      pageEl.removeAttribute('data-virtual'); if (window.Iconify) { try { Iconify.scan(pageEl); } catch (_) {} }
    },
    renderDesktopItem: function renderEngineRenderDesktopItem(item, pageIndex, localIndex) {
      var displayTitle = item.title || '', tabIndex = 0;
      if (item.type === 'folder') return '<div class="app-icon" data-id="' + item.id + '" data-scope="desktop" data-item-type="folder" data-page-index="' + pageIndex + '" data-local-index="' + localIndex + '" tabindex="' + tabIndex + '" role="button" aria-label="文件夹：' + escapeHtml(displayTitle) + '"><div class="icon-bg" style="background:rgba(255,255,255,.18);">' + this.renderFolderPreview(item) + '</div><div class="icon-label-wrap"><div class="icon-label">' + escapeHtml(displayTitle) + '</div></div></div>';
      var bgStyle = item.bgStyle || '';
      return '<div class="app-icon" data-id="' + item.id + '" data-scope="desktop" data-item-type="app" data-page-index="' + pageIndex + '" data-local-index="' + localIndex + '" tabindex="' + tabIndex + '" role="link" aria-label="应用：' + escapeHtml(displayTitle) + '"><div class="icon-bg" style="' + bgStyle + '">' + renderIconContent(item) + '</div><div class="icon-label-wrap"><div class="icon-label">' + escapeHtml(displayTitle) + '</div></div></div>';
    },
    renderDockItem: function renderEngineRenderDockItem(item, index) { 
      if (item.type === 'folder') return ''; 
      var displayTitle = item.title || '';
      var bgStyle = item.bgStyle || '';
      return '<div class="app-icon" data-id="' + item.id + '" data-scope="dock" data-item-type="app" data-local-index="' + index + '" tabindex="0" role="link" aria-label="' + escapeHtml(displayTitle) + '"><div class="icon-bg" style="' + bgStyle + '">' + renderIconContent(item) + '</div><div class="icon-label-wrap"><div class="icon-label">' + escapeHtml(displayTitle) + '</div></div></div>'; 
    },
    renderFolderChild: function renderEngineRenderFolderChild(item, index, folderId) { 
      var displayTitle = item.title || '';
      var bgStyle = item.bgStyle || '';
      return '<div class="app-icon" data-id="' + item.id + '" data-scope="folder" data-folder-id="' + folderId + '" data-child-index="' + index + '" tabindex="0" role="link" aria-label="' + escapeHtml(displayTitle) + '"><div class="icon-bg" style="' + bgStyle + '">' + renderIconContent(item) + '</div><div class="icon-label-wrap"><div class="icon-label">' + escapeHtml(displayTitle) + '</div></div></div>'; 
    },
    renderFolderPreview: function renderEngineRenderFolderPreview(folderItem) { 
      var preview = folderItem.children.slice(0, 4), cells = []; 
      for (var i = 0; i < 4; i++) { 
        var child = preview[i]; 
        var cellStyle = '';
        if (child && child.bgStyle) {
          cellStyle = child.bgStyle;
        } else {
          cellStyle = 'background:rgba(255,255,255,.08);';
        }
        cells.push('<div class="folder-preview-cell" style="' + cellStyle + '">' + (child ? renderIconContent(child) : '') + '</div>'); 
      } 
      return '<div class="folder-preview">' + cells.join('') + '</div>'; 
    },
    renderDock: function renderEngineRenderDock() { 
      var self = this; 
      refs.dock.innerHTML = appStore.dock.items.map(function renderDockMap(item, i) { return self.renderDockItem(item, i); }).join(''); 
    },
    renderIndicators: function renderEngineRenderIndicators() { 
      var count = appStore.getPageCount(), current = appStore.currentPage; 
      refs.indicators.innerHTML = Array.from({ length: count }).map(function renderIndicatorsMap(_, i) { 
        var isActive = i === current; 
        return '<span class="indicator-dot ' + (isActive ? 'active' : '') + '" data-page="' + i + '" tabindex="0" role="tab" aria-label="第' + (i + 1) + '页" aria-selected="' + isActive + '"></span>'; 
      }).join(''); 
    },
    renderFolderModal: function renderEngineRenderFolderModal() {
      if (!appStore.folderModalId) { refs.folderModal.classList.remove('active'); refs.folderGrid.innerHTML = ''; return; }
      var folder = appStore.desktop.items.find(function findFolderModalFolder(i) { return i.id === appStore.folderModalId && i.type === 'folder'; });
      if (!folder) { appStore.folderModalId = null; refs.folderModal.classList.remove('active'); refs.folderGrid.innerHTML = ''; return; }
      if (refs.folderTitle) refs.folderTitle.textContent = folder.title || '文件夹'; var self = this;
      refs.folderGrid.innerHTML = folder.children.map(function renderFolderModalChild(child, index) { return self.renderFolderChild(child, index, folder.id); }).join('');
      refs.folderEmpty.style.display = folder.children.length ? 'none' : 'block'; refs.folderModal.classList.add('active'); this.setupFocusTrap(refs.folderModal);
    },
    setupFocusTrap: function renderEngineSetupFocusTrap(modal) { 
      var focusableElements = modal.querySelectorAll('button, [tabindex]:not([tabindex="-1"])'); 
      if (focusableElements.length > 0) focusableElements[0].focus(); 
    }
  };

  // ==================== 页面管理器 ====================
  var pageManager = {
    updateTransform: function pageManagerUpdateTransform(withTransition) {
      refs.pagesContainer.style.transition = withTransition ? 'transform .42s cubic-bezier(.22,.88,.24,1)' : 'none';
      refs.pagesContainer.style.transform = 'translate3d(-' + appStore.currentPage * window.innerWidth + 'px,0,0)';
      querySelectorAll('.indicator-dot', refs.indicators).forEach(function updateTransformEach(dot, i) { var isActive = i === appStore.currentPage; dot.classList.toggle('active', isActive); dot.setAttribute('aria-selected', isActive); });
      querySelectorAll('.page', refs.pagesContainer).forEach(function updateTransformPageEach(page, i) { page.classList.toggle('page-current', i === appStore.currentPage); page.classList.toggle('page-prev', i === appStore.currentPage - 1); page.classList.toggle('page-next', i === appStore.currentPage + 1); });
    },
    turnTo: function pageManagerTurnTo(targetPage) {
      var currentPage = appStore.currentPage; appStore.currentPage = targetPage; renderEngine.cleanupFLIP();
      var currentPageEls = querySelectorAll('.page[data-page-index="' + currentPage + '"] .app-icon');
      currentPageEls.forEach(function turnOutEach(el, i) { el.style.transition = 'transform 0.3s ease ' + (i * 0.02) + 's, opacity 0.3s ease ' + (i * 0.02) + 's'; el.style.transform = targetPage > currentPage ? 'translateX(-30px)' : 'translateX(30px)'; el.style.opacity = '0.6'; });
      this.updateTransform(true);
      if (appStore.desktop.items.length > VIRTUAL_SCROLL_THRESHOLD) { renderEngine.loadVirtualPage(targetPage); if (targetPage > 0) renderEngine.loadVirtualPage(targetPage - 1); if (targetPage < appStore.getPageCount() - 1) renderEngine.loadVirtualPage(targetPage + 1); }
      setTimeout(function turnToTimeout() {
        var targetPageEls = querySelectorAll('.page[data-page-index="' + targetPage + '"] .app-icon');
        targetPageEls.forEach(function turnInEach(el, i) { el.style.transition = 'none'; el.style.transform = targetPage > currentPage ? 'translateX(40px)' : 'translateX(-40px)'; el.style.opacity = '0.5'; el.offsetHeight; requestAnimationFrame(function handleTurnInRAF() { el.style.transition = 'all 0.4s cubic-bezier(0.2, 0.8, 0.2, 1) ' + (i * 0.03) + 's'; el.style.transform = 'translateX(0)'; el.style.opacity = '1'; }); });
        setTimeout(function cleanupTurnIn() { currentPageEls.forEach(function cleanupTurnInEach(el) { el.style.transition = ''; el.style.transform = ''; el.style.opacity = ''; }); }, 350);
      }, 50);
      appStore.save();
    }
  };

  // ==================== 拖拽交互辅助 ====================
  var dragInteraction = {
    setDeleteZoneVisible: function dragInteractionSetDeleteZoneVisible(visible) { refs.deleteZone.classList.toggle('active', !!visible); },
    setDeleteZoneHover: function dragInteractionSetDeleteZoneHover(hover) { dragStore.overDelete = !!hover; refs.deleteZone.classList.toggle('hover', !!hover); },
    createGhost: function dragInteractionCreateGhost(el) { 
      var rect = el.getBoundingClientRect(), wrap = document.createElement('div'); 
      wrap.className = 'drag-ghost'; wrap.style.width = rect.width + 'px'; wrap.style.height = rect.height + 'px'; 
      wrap.style.willChange = 'transform'; wrap.dataset.ghostId = dragStore.itemId || 'ghost'; 
      var clone = el.cloneNode(true); 
      clone.classList.remove('drag-source', 'exchange-target', 'merge-hover'); 
      clone.removeAttribute('tabindex'); wrap.appendChild(clone); document.body.appendChild(wrap); 
      return wrap; 
    },
    updateGhostPosition: function dragInteractionUpdateGhostPosition(x, y) { 
      if (!dragStore.ghostEl) return; 
      var offsetX = dragStore.dragOffsetX || (dragStore.ghostEl.offsetWidth / 2), offsetY = dragStore.dragOffsetY || (dragStore.ghostEl.offsetHeight / 2), finalX = x - offsetX, finalY = y - offsetY; 
      dragStore.ghostEl.style.transform = 'translate3d(' + finalX + 'px, ' + finalY + 'px, 0)'; 
    },
    clearMergeHover: function dragInteractionClearMergeHover() { querySelectorAll('.merge-hover').forEach(function clearMergeHoverEach(el) { el.classList.remove('merge-hover'); }); },
    forceCleanup: function dragInteractionForceCleanup() { 
      if (dragStore.ghostEl) { try { dragStore.ghostEl.remove(); } catch(e) {} dragStore.ghostEl = null; } 
      querySelectorAll('.drag-ghost').forEach(function forceCleanupGhostEach(el) { try { el.remove(); } catch(e) {} }); 
      querySelectorAll('.drag-source').forEach(function forceCleanupSourceEach(el) { el.classList.remove('drag-source'); }); 
      querySelectorAll('.exchange-target').forEach(function forceCleanupExchangeEach(el) { el.classList.remove('exchange-target'); }); 
      querySelectorAll('.merge-hover').forEach(function forceCleanupMergeEach(el) { el.classList.remove('merge-hover'); }); 
      refs.deleteZone.classList.remove('active', 'hover'); 
    }
  };

  // ==================== 搜索功能 ====================
  function setupSearch() {
    var input = querySelector('#searchInput');
    if (input) {
      input.addEventListener('focus', function searchInputFocusHandler() { if (!searchStore.searchScreenLock) openSearchScreen(); });
      input.addEventListener('keydown', function searchInputKeydownHandler(e) { 
        if (e.key !== 'Enter') return; 
        var keyword = input.value.trim(); 
        if (!keyword) return; 
        searchStore.addHistory(keyword); 
        handleSearchOrUrl(keyword, searchStore.currentEngine); 
      });
    }
    var searchScreenInput = querySelector('#searchScreenInput');
    if (searchScreenInput) {
      searchScreenInput.addEventListener('keydown', function searchScreenInputKeydownHandler(e) { 
        if (e.key !== 'Enter') return; 
        var keyword = searchScreenInput.value.trim(); 
        if (!keyword) return; 
        searchStore.addHistory(keyword); 
        handleSearchOrUrl(keyword, searchStore.currentEngine); 
        closeSearchScreen(); 
      });
      searchScreenInput.addEventListener('input', debounce(function searchScreenInputHandler(e) {
        document.getElementById('searchScreenEnginePanel').classList.remove('active');
        var val = e.target.value.trim();
        if (!val) { renderSuggestionsToBody([]); return; }
        renderSuggestionsToBody([]);
        fetchSearchSuggestionsWithFallback(val);
      }, 150));
      searchScreenInput.addEventListener('blur', function searchScreenInputBlurHandler() { 
        setTimeout(function searchScreenBlurTimeout() { 
          var activeEl = document.activeElement, isInSearchScreen = refs.searchScreen.contains(activeEl); 
          if (!isInSearchScreen && !searchStore.searchScreenLock) closeSearchScreen(); 
        }, 200); 
      });
      searchScreenInput.addEventListener('focus', function searchScreenInputFocusHandler() { 
        var val = searchScreenInput.value.trim(); 
        if (!val) renderSuggestionsToBody([]); 
      });
    }
  }

  window.handleRemoteSuggestionsCallback = function handleRemoteSuggestionsCallback(data) {
    var suggestions = [];
    if (data && data.s && Array.isArray(data.s)) {
      suggestions = data.s.filter(Boolean);
    }
    searchStore.suggestions = suggestions;
    renderSuggestionsToBody(suggestions);
  };

  function fetchSearchSuggestionsJSONP(val) {
    var scriptId = 'baidu-suggest-script';
    var existingScript = document.getElementById(scriptId);
    if (existingScript) existingScript.remove();
    
    var script = document.createElement('script');
    script.id = scriptId;
    script.src = 'https://www.baidu.com/su?wd=' + encodeURIComponent(val) + '&cb=window.handleRemoteSuggestionsCallback';
    script.async = true;
    script.onload = function scriptOnloadHandler() { 
      setTimeout(function removeScriptTimeout() { 
        var s = document.getElementById(scriptId); 
        if (s) s.remove(); 
      }, 100); 
    };
    script.onerror = function scriptOnerrorHandler() { 
      var s = document.getElementById(scriptId); 
      if (s) s.remove(); 
      searchStore.suggestions = [];
      renderSuggestionsToBody([]);
    };
    document.body.appendChild(script);
    
    setTimeout(function jsonpTimeoutHandler() {
      var s = document.getElementById(scriptId);
      if (s) {
        s.remove();
        searchStore.suggestions = [];
        renderSuggestionsToBody([]);
      }
    }, 5000);
  }

  function fetchSearchSuggestionsWithFallback(val) {
    var apiUrl = 'https://www.baidu.com/sugrec?prod=pc&wd=' + encodeURIComponent(val);
    
    fetch(apiUrl, {
      method: 'GET',
      credentials: 'omit',
      headers: {
        'Accept': 'application/json, text/javascript, */*'
      }
    })
    .then(function fetchSuggestionsThen(res) { 
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json(); 
    })
    .then(function fetchSuggestionsJson(data) {
      var suggestions = [];
      if (data && data.g && Array.isArray(data.g)) {
        suggestions = data.g.map(function suggestionMap(item) { return item.q; }).filter(Boolean);
      }
      searchStore.suggestions = suggestions;
      renderSuggestionsToBody(suggestions);
    })
    .catch(function fetchSuggestionsCatch(err) {
      fetchSearchSuggestionsJSONP(val);
    });
  }

  function fetchSearchSuggestions(val) {
    fetchSearchSuggestionsWithFallback(val);
  }

  function renderSuggestionsToBody(remoteSuggestions) {
    remoteSuggestions = remoteSuggestions || [];
    var container = refs.searchScreenBody;
    if (!container) return;
    searchStore.getHistory().then(function renderSuggestionsHistory(history) {
      var hasContent = history.length > 0 || remoteSuggestions.length > 0;
      if (!hasContent) { container.innerHTML = '<div class="suggest-empty">输入关键词查看搜索建议</div>'; return; }
      var html = '<div class="suggest-list-container">';
      if (remoteSuggestions.length > 0) {
        html += '<div class="suggest-section-title">搜索建议</div><div class="suggest-list">';
        remoteSuggestions.forEach(function remoteSuggestionEach(text) { 
          html += '<div class="suggest-item" data-suggest-action="execute" data-text="' + escapeHtml(text) + '" tabindex="0" role="button"><span class="iconify" data-icon="mdi:magnify"></span><span class="suggest-text">' + escapeHtml(text) + '</span><div class="suggest-arrow" data-suggest-action="fill" data-text="' + escapeHtml(text) + '" tabindex="0" role="button" title="填入搜索框"><span class="iconify" data-icon="mdi:arrow-top-left"></span></div></div>'; 
        });
        html += '</div>';
      }
      if (history.length > 0) {
        html += '<div class="suggest-history-header" style="margin-top: 24px;"><div class="suggest-section-title" style="margin: 0;">搜索历史</div><div class="suggest-clear-history" data-action="clear-history" tabindex="0" role="button">清除全部</div></div><div class="suggest-list">';
        history.forEach(function historyEach(text) { 
          html += '<div class="suggest-item" data-suggest-action="execute" data-text="' + escapeHtml(text) + '" tabindex="0" role="button"><span class="iconify" data-icon="mdi:history"></span><span class="suggest-text">' + escapeHtml(text) + '</span><div class="suggest-arrow" data-suggest-action="remove" data-text="' + escapeHtml(text) + '" tabindex="0" role="button" title="删除记录"><span class="iconify" data-icon="mdi:close"></span></div></div>'; 
        });
        html += '</div>';
      }
      html += '</div>';
      container.innerHTML = html;
      if (window.Iconify) { try { Iconify.scan(container); } catch (_) {} }
    });
  }

  function handleSearchOrUrl(keyword, engine) {
    if (!keyword) return false;
    var trimmedKeyword = keyword.trim(), mainInput = document.getElementById('searchInput'), searchScreenInput = document.getElementById('searchScreenInput');
    if (mainInput) mainInput.disabled = false;
    function isUrl(input) {
      if (!input || typeof input !== 'string') return false;
      var trimmed = input.trim(); if (trimmed === '') return false;
      if (/^https?:\/\//i.test(trimmed)) { try { new URL(trimmed); return true; } catch (e) { return false; } }
      var domainPattern = /^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/;
      var ipPattern = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?(\/.*)?$/;
      var localhostPattern = /^localhost(:\d+)?(\/.*)?$/i;
      if (domainPattern.test(trimmed) || ipPattern.test(trimmed) || localhostPattern.test(trimmed)) return true;
      if (!trimmed.includes('.') || /[\u4e00-\u9fa5\s]/.test(trimmed)) return false;
      try { new URL('https://' + trimmed); return true; } catch (e) { return false; }
    }
    if (isUrl(trimmedKeyword)) { 
      var url = trimmedKeyword; 
      if (!/^https?:\/\//i.test(url)) url = 'https://' + url; 
      window.open(url, '_blank'); 
      if (mainInput) mainInput.value = ''; 
      if (searchScreenInput) searchScreenInput.value = ''; 
      return true; 
    }
    else {
      if (!engine || !engine.url) engine = searchStore.engines.find(function findDefaultEngine(e) { return e.id === 'preset-2'; }) || searchStore.engines[2];
      var searchUrl = engine.url.replace('%s', encodeURIComponent(trimmedKeyword)); 
      window.open(searchUrl, '_blank');
      if (mainInput) mainInput.value = ''; 
      if (searchScreenInput) searchScreenInput.value = ''; 
      return false;
    }
  }

  function openSearchScreen() {
    if (searchStore.searchScreenLock) return; 
    searchStore.searchScreenLock = true;
    var mainInput = querySelector('#searchInput'); 
    if (mainInput) { mainInput.blur(); mainInput.disabled = true; }
    refs.searchScreen.classList.add('active');
    if (refs.searchScreenInput) refs.searchScreenInput.value = mainInput ? mainInput.value : '';
    searchStore.syncIcons(); 
    renderSuggestionsToBody([]);
    setTimeout(function openSearchScreenTimeout() { 
      var val = refs.searchScreenInput.value.trim(); 
      if (!val) renderSuggestionsToBody([]); 
    }, 50);
    requestAnimationFrame(function openSearchScreenRAF1() { 
      requestAnimationFrame(function openSearchScreenRAF2() { 
        setTimeout(function openSearchScreenFocusTimeout() { 
          if (refs.searchScreenInput) { 
            refs.searchScreenInput.focus(); 
            refs.searchScreenInput.select(); 
          } 
          searchStore.searchScreenLock = false; 
          if (mainInput) mainInput.disabled = false; 
        }, 300); 
      }); 
    });
    window.history.pushState({ searchOpen: true }, '搜索', ''); 
    window.addEventListener('popstate', handleSearchPopState);
  }

  function closeSearchScreen() {
    if (searchStore.searchScreenLock) return; 
    refs.searchScreen.classList.remove('active');
    if (refs.searchScreenInput) refs.searchScreenInput.value = '';
    var mainInput = querySelector('#searchInput');
    if (mainInput) { mainInput.value = ''; mainInput.disabled = false; mainInput.blur(); }
    document.getElementById('searchScreenEnginePanel').classList.remove('active');
    if (refs.searchScreenInput) refs.searchScreenInput.blur();
    window.removeEventListener('popstate', handleSearchPopState);
    if (window.history.state && window.history.state.searchOpen) window.history.back();
  }

  function handleSearchPopState(e) { if (!(e.state && e.state.searchOpen)) closeSearchScreen(); }

  function toggleEnginePanel() {
    var panel = document.getElementById('enginePanel');
    if (panel) {
      var isActive = panel.classList.contains('active');
      if (isActive) {
        panel.classList.remove('active');
      } else {
        renderEngineList();
        panel.classList.add('active');
      }
    }
  }
  function toggleSearchScreenEnginePanel() {
    var panel = document.getElementById('searchScreenEnginePanel');
    if (panel) {
      var isActive = panel.classList.contains('active');
      if (isActive) {
        panel.classList.remove('active');
      } else {
        renderEngineList();
        panel.classList.add('active');
      }
    }
  }

  // ==================== 搜索引擎长按上下文菜单 ====================
  var engineLongPressState = {
    timer: null,
    targetEngineId: null,
    startX: 0,
    startY: 0,
    isLongPress: false
  };

  function resetEngineLongPress() {
    if (engineLongPressState.timer) {
      clearTimeout(engineLongPressState.timer);
      engineLongPressState.timer = null;
    }
    engineLongPressState.targetEngineId = null;
    engineLongPressState.isLongPress = false;
  }

  function handleEnginePointerDown(e) {
    var engineItem = e.target.closest('.engine-item[data-engine-id]');
    if (!engineItem) return;
    var engineId = engineItem.dataset.engineId;
    if (engineId.startsWith('preset-')) return;
    engineLongPressState.targetEngineId = engineId;
    engineLongPressState.startX = e.clientX;
    engineLongPressState.startY = e.clientY;
    engineLongPressState.isLongPress = false;
    engineLongPressState.timer = setTimeout(function engineLongPressTimeout() {
      engineLongPressState.isLongPress = true;
      showEngineContextMenu(engineLongPressState.startX, engineLongPressState.startY, engineId);
    }, 500);
  }

  function handleEnginePointerMove(e) {
    if (!engineLongPressState.timer) return;
    var dx = e.clientX - engineLongPressState.startX;
    var dy = e.clientY - engineLongPressState.startY;
    if (Math.hypot(dx, dy) > 10) {
      resetEngineLongPress();
    }
  }

  function handleEnginePointerUp(e) {
    if (engineLongPressState.timer) {
      clearTimeout(engineLongPressState.timer);
      engineLongPressState.timer = null;
    }
    if (engineLongPressState.isLongPress) {
      e.preventDefault();
      e.stopPropagation();
    }
    engineLongPressState.isLongPress = false;
    engineLongPressState.targetEngineId = null;
  }

  function showEngineContextMenu(x, y, engineId) {
    var engine = searchStore.engines.find(function findEngine(e) { return e.id === engineId; });
    if (!engine) return;
    state.engineContextTarget = engine;
    if (refs.engineContextMenu) {
      refs.engineContextMenu.style.visibility = 'hidden';
      refs.engineContextMenu.style.left = '0';
      refs.engineContextMenu.style.top = '0';
      refs.engineContextMenu.classList.add('active');
      var menuRect = refs.engineContextMenu.getBoundingClientRect();
      var menuWidth = menuRect.width;
      var menuHeight = menuRect.height;
      var viewportWidth = window.innerWidth;
      var viewportHeight = window.innerHeight;
      var safeMargin = 8;
      var left = x;
      if (left + menuWidth > viewportWidth - safeMargin) {
        left = Math.max(x - menuWidth, safeMargin);
      } else {
        left = Math.max(left, safeMargin);
      }
      var top = y;
      if (top + menuHeight > viewportHeight - safeMargin) {
        top = Math.max(y - menuHeight, safeMargin);
      } else {
        top = Math.max(top, safeMargin);
      }
      refs.engineContextMenu.style.left = left + 'px';
      refs.engineContextMenu.style.top = top + 'px';
      refs.engineContextMenu.style.visibility = 'visible';
    }
    if (window.Iconify && refs.engineContextMenu) {
      try { Iconify.scan(refs.engineContextMenu); } catch (_) {}
    }
  }

  function hideEngineContextMenu() {
    if (refs.engineContextMenu) {
      refs.engineContextMenu.classList.remove('active');
    }
    state.engineContextTarget = null;
  }

  function openEngineEditModal() {
    var engine = state.engineContextTarget;
    if (!engine) return;
    hideEngineContextMenu();
    refs.engineFormModal.classList.add('active');
    document.getElementById('enginePanel').classList.remove('active');
    document.getElementById('searchScreenEnginePanel').classList.remove('active');
    refs.engineFormTitle.textContent = '编辑搜索引擎';
    refs.engineFormName.value = engine.name || '';
    refs.engineFormIcon.value = engine.icon || '';
    refs.engineFormUrl.value = engine.url || '';
    clearEngineIconPreview();
    if (engine.icon) updateEngineIconPreview(engine.icon);
    state.engineEditMode = true;
    state.engineEditId = engine.id;
    refs.engineFormName.focus();
  }

  function deleteEngineFromContextMenu() {
    var engine = state.engineContextTarget;
    if (!engine) return;
    hideEngineContextMenu();
    if (confirm('确定删除搜索引擎"' + engine.name + '"吗？')) {
      if (searchStore.deleteCustomEngine(engine.id)) {
        renderEngineList();
        showToast('已删除');
      }
    }
  }

  function bindEngineLongPressEvents(container) {
    if (!container) return;
    container.addEventListener('pointerdown', handleEnginePointerDown, { passive: true });
    container.addEventListener('pointermove', handleEnginePointerMove, { passive: true });
    container.addEventListener('pointerup', handleEnginePointerUp, { passive: false });
    container.addEventListener('pointercancel', resetEngineLongPress, { passive: true });
  }

  function buildEngineItemEl(engine) {
    var isCustom = !engine.id.startsWith('preset-');
    var isActive = engine.id === searchStore.currentEngine.id;
    var item = document.createElement('div');
    item.className = 'engine-item' + (isActive ? ' active' : '');
    item.setAttribute('data-engine-id', engine.id);
    item.setAttribute('data-is-custom', String(isCustom));
    item.setAttribute('tabindex', '0');
    item.setAttribute('role', 'button');
    var iconEl;
    if (isImageIcon(engine.icon)) {
      iconEl = document.createElement('img');
      iconEl.className = 'engine-img-icon';
      iconEl.src = engine.icon;
      iconEl.alt = '';
      iconEl.setAttribute('draggable', 'false');
    } else {
      iconEl = document.createElement('span');
      iconEl.className = 'iconify';
      iconEl.setAttribute('data-icon', engine.icon || 'mdi:magnify');
    }
    var nameEl = document.createElement('span');
    nameEl.className = 'engine-name';
    nameEl.textContent = engine.name;
    item.appendChild(iconEl);
    item.appendChild(nameEl);
    return item;
  }

  function buildAddEngineBtn() {
    var btn = document.createElement('div');
    btn.className = 'engine-item add-btn';
    btn.setAttribute('data-action', 'add-engine');
    btn.setAttribute('tabindex', '0');
    btn.setAttribute('role', 'button');
    var iconEl = document.createElement('span');
    iconEl.className = 'iconify';
    iconEl.setAttribute('data-icon', 'mdi:plus');
    var nameEl = document.createElement('span');
    nameEl.className = 'engine-name';
    nameEl.textContent = '添加';
    btn.appendChild(iconEl);
    btn.appendChild(nameEl);
    return btn;
  }

  function populateEngineList(listEl) {
    if (!listEl) return;
    listEl.innerHTML = '';
    searchStore.engines.forEach(function renderEngineForEach(engine) {
      listEl.appendChild(buildEngineItemEl(engine));
    });
    listEl.appendChild(buildAddEngineBtn());
    if (window.Iconify) { try { Iconify.scan(listEl); } catch (_) {} }
    bindEngineLongPressEvents(listEl);
  }

  function renderEngineList() {
    populateEngineList(document.getElementById('engineList'));
    populateEngineList(document.getElementById('searchScreenEngineList'));
  }

  function switchEngine(engineId) {
    var targetEngine = searchStore.engines.find(function findSwitchEngine(e) { return e.id === engineId; });
    if (!targetEngine) return; 
    searchStore.currentEngine = targetEngine; 
    searchStore.syncIcons();
    document.getElementById('enginePanel').classList.remove('active');
    document.getElementById('searchScreenEnginePanel').classList.remove('active');
    showToast('已切换至' + targetEngine.name + '搜索'); 
    appStore.save();
  }

  function deleteEngine(engineId) {
    if (!engineId || engineId.startsWith('preset-')) return;
    var engine = searchStore.engines.find(function findDelEngine(e) { return e.id === engineId; });
    if (!engine) return;
    if (confirm('确定删除搜索引擎"' + engine.name + '"吗？')) {
      if (searchStore.deleteCustomEngine(engineId)) {
        renderEngineList();
        showToast('已删除');
      }
    }
  }
  function clearEngineIconPreview() {
    var previewRow = document.getElementById('engineIconPreviewRow');
    var previewEl = document.getElementById('engineIconPreview');
    var fileInput = document.getElementById('engineIconFileInput');
    if (previewRow) previewRow.style.display = 'none';
    if (previewEl) previewEl.innerHTML = '';
    if (fileInput) fileInput.value = '';
  }

  function updateEngineIconPreview(iconValue) {
    var previewRow = document.getElementById('engineIconPreviewRow');
    var previewEl = document.getElementById('engineIconPreview');
    if (!previewRow || !previewEl) return;
    if (!iconValue) { previewRow.style.display = 'none'; previewEl.innerHTML = ''; return; }
    previewRow.style.display = 'flex';
    previewEl.innerHTML = '';
    if (isImageIcon(iconValue)) {
      var img = document.createElement('img');
      img.src = iconValue;
      img.alt = '';
      img.setAttribute('draggable', 'false');
      previewEl.appendChild(img);
    } else {
      var span = document.createElement('span');
      span.className = 'iconify';
      span.setAttribute('data-icon', iconValue);
      previewEl.appendChild(span);
      if (window.Iconify) { try { Iconify.scan(previewEl); } catch (_) {} }
    }
  }

  function openEngineFormModal() {
    refs.engineFormModal.classList.add('active');
    document.getElementById('enginePanel').classList.remove('active');
    document.getElementById('searchScreenEnginePanel').classList.remove('active');
    refs.engineFormTitle.textContent = '添加搜索引擎';
    refs.engineFormName.value = '';
    refs.engineFormIcon.value = '';
    refs.engineFormUrl.value = '';
    clearEngineIconPreview();
    state.engineEditMode = false;
    state.engineEditId = null;
    refs.engineFormName.focus();
  }
  function closeEngineFormModal() {
    refs.engineFormModal.classList.remove('active');
    refs.engineFormName.value = '';
    refs.engineFormIcon.value = '';
    refs.engineFormUrl.value = '';
    refs.engineFormTitle.textContent = '添加搜索引擎';
    clearEngineIconPreview();
    state.engineEditMode = false;
    state.engineEditId = null;
  }
  function saveCustomEngine() {
    var name = refs.engineFormName.value.trim();
    var iconRaw = refs.engineFormIcon.value.trim();
    var icon = iconRaw || 'mdi:magnify';
    var url = refs.engineFormUrl.value.trim();
    if (!name) { showToast('请输入引擎名称'); return; }
    if (!url) { showToast('请输入搜索URL'); return; }
    if (url.indexOf('%s') < 0) { showToast('URL 必须包含 %s 作为搜索词占位符'); return; }
    var finalUrl = url.indexOf('%s') > -1 ? url : url + '%s';
    if (state.engineEditMode && state.engineEditId) {
      var engine = searchStore.engines.find(function findEditEngine(e) { return e.id === state.engineEditId; });
      if (engine) {
        engine.name = name;
        engine.icon = icon;
        engine.url = finalUrl;
        searchStore.saveCustomEngines();
        if (searchStore.currentEngine.id === state.engineEditId) {
          searchStore.currentEngine = engine;
          searchStore.syncIcons();
        }
        showToast('已保存');
      }
      state.engineEditMode = false;
      state.engineEditId = null;
    } else {
      searchStore.addCustomEngine(name, icon, finalUrl);
      showToast('已添加自定义搜索引擎');
    }
    closeEngineFormModal();
    renderEngineList();
  }

  // ==================== 同步模态框 UI ====================
  function openSyncModal() {
    refs.syncModal.classList.add('active'); 
    if (refs.githubToken) refs.githubToken.value = syncStore.config.token || ''; 
    if (refs.githubRepo) refs.githubRepo.value = syncStore.config.repo || '';
    var intervalSelect = document.getElementById('syncIntervalSelect'); 
    if (intervalSelect) intervalSelect.value = syncStore.config.syncInterval || 0;
    var config = syncStore.config, hasConfig = config.token && config.owner;
    var iconEl = document.getElementById('syncStatusIcon'), titleEl = document.getElementById('syncStatusTitle'), descEl = document.getElementById('syncStatusDesc');
    if (hasConfig) { 
      if (iconEl) { iconEl.className = 'sync-status-icon success'; iconEl.innerHTML = '<span class="iconify" data-icon="mdi:cloud-check-outline"></span>'; }
      if (titleEl) titleEl.textContent = '已配置同步'; 
      if (descEl) descEl.textContent = '用户: ' + config.owner + ' | 仓库: ' + (config.repo || '未指定'); 
    } else { 
      if (iconEl) { iconEl.className = 'sync-status-icon'; iconEl.innerHTML = '<span class="iconify" data-icon="mdi:cloud-off-outline"></span>'; }
      if (titleEl) titleEl.textContent = '未配置同步'; 
      if (descEl) descEl.textContent = '设置GitHub令牌以启用云同步'; 
    }
    if (window.Iconify && iconEl) { try { Iconify.scan(iconEl); } catch(_) {} }
    updateSyncTimeInfo(); 
    if (refs.githubToken) refs.githubToken.focus();
  }

  function closeSyncModal() { if (refs.syncModal) refs.syncModal.classList.remove('active'); }
  function manualPushToGithub() {
    var token = refs.githubToken ? refs.githubToken.value.trim() : '', 
        repo = refs.githubRepo ? refs.githubRepo.value.trim() : '', 
        intervalSelect = document.getElementById('syncIntervalSelect'), 
        interval = intervalSelect ? parseInt(intervalSelect.value) || 0 : 0;
    syncStore.updateSyncInterval(interval);
    function continuePush() { 
      if (repo !== syncStore.config.repo) syncStore.config.repo = repo; 
      syncStore.save(); 
      updateSyncTimeInfo(); 
      syncStore.push(true); 
    }
    if (token !== syncStore.config.token) { 
      syncStore.validateToken(token).then(function validateTokenThen() { continuePush(); }); 
    } else { 
      continuePush(); 
    }
  }
  function manualPullFromGithub() {
    var token = refs.githubToken ? refs.githubToken.value.trim() : '', 
        repo = refs.githubRepo ? refs.githubRepo.value.trim() : '', 
        intervalSelect = document.getElementById('syncIntervalSelect'), 
        interval = intervalSelect ? parseInt(intervalSelect.value) || 0 : 0;
    syncStore.updateSyncInterval(interval);
    function continuePull() { 
      if (repo !== syncStore.config.repo) syncStore.config.repo = repo; 
      syncStore.save(); 
      updateSyncTimeInfo(); 
      syncStore.pull(); 
    }
    if (token !== syncStore.config.token) { 
      syncStore.validateToken(token).then(function validateTokenThen() { continuePull(); }); 
    } else { 
      continuePull(); 
    }
  }
  function handleSyncIntervalChange() { 
    var intervalSelect = document.getElementById('syncIntervalSelect'), 
        interval = intervalSelect ? parseInt(intervalSelect.value) || 0 : 0; 
    syncStore.updateSyncInterval(interval);
    if (interval > 0) showToast('已设置每' + interval + '天自动同步'); 
    else showToast('已关闭自动同步'); 
  }
  function updateSyncTimeInfo() {
    var lastSync = syncStore.config.lastSyncTime, 
        lastInfoEl = document.getElementById('lastSyncInfo'), 
        nextInfoEl = document.getElementById('nextSyncInfo');
    if (lastSync && lastInfoEl) lastInfoEl.textContent = '上次同步: ' + new Date(lastSync).toLocaleString('zh-CN'); 
    else if (lastInfoEl) lastInfoEl.textContent = '尚未进行同步';
    var intervalSelect = document.getElementById('syncIntervalSelect'), 
        interval = intervalSelect ? parseInt(intervalSelect.value) || 0 : 0;
    if (nextInfoEl) { 
      if (interval > 0 && lastSync) { 
        var nextSync = new Date(lastSync); 
        nextSync.setDate(nextSync.getDate() + interval); 
        var diffHours = Math.round((nextSync - new Date()) / (1000 * 60 * 60)); 
        if (diffHours > 24) nextInfoEl.textContent = '预计下次同步: ' + Math.ceil(diffHours / 24) + '天后'; 
        else if (diffHours > 0) nextInfoEl.textContent = '预计下次同步: ' + diffHours + '小时后'; 
        else nextInfoEl.textContent = '预计下次同步: 即将进行'; 
      } else if (interval > 0) nextInfoEl.textContent = '预计下次同步: 数据变更后'; 
      else nextInfoEl.textContent = '自动同步已关闭'; 
    }
  }

  // ==================== 壁纸与风格管理 ====================
  function applyWallpaper(url) { 
    if (!url || currentStyle === 'neumorphism') return; // 新拟态下不应用壁纸
    storageAdapter.setItem(STORAGE_KEYS.WALLPAPER, url); 
    applyWallpaperStyle(url);
    showToast('壁纸已更新'); 
  }
  
  function resetWallpaper() { 
    storageAdapter.setItem(STORAGE_KEYS.WALLPAPER, 'default'); 
    if (currentStyle === 'glass') {
      loadWallpaperForGlass();
    } else {
      resetWallpaperToDefault();
    }
    showToast('已恢复默认背景'); 
  }
  
  function closeWallpaperModal() { if (refs.wallpaperModal) refs.wallpaperModal.classList.remove('active'); }
  
  // 风格切换按钮事件绑定
  function bindStyleToggleEvents() {
    var neumorphismBtn = document.getElementById('styleNeumorphism');
    var glassBtn = document.getElementById('styleGlass');
    
    if (neumorphismBtn) {
      neumorphismBtn.addEventListener('click', function() {
        switchStyle('neumorphism');
      });
    }
    
    if (glassBtn) {
      glassBtn.addEventListener('click', function() {
        switchStyle('glass');
      });
    }
  }

  // ==================== 其他 UI 函数 ====================
  function checkQuoteScroll() { 
    var quoteText = querySelector('#quoteDisplay'), quoteTextWrap = querySelector('.quote-text-wrap'); 
    if (!quoteText || !quoteTextWrap) return; 
    quoteText.classList.remove('scroll'); 
    if (quoteText.scrollWidth > quoteTextWrap.clientWidth) quoteText.classList.add('scroll'); 
  }
  function editQuote() { 
    if (refs.quoteDisplayWrap) refs.quoteDisplayWrap.style.display = 'none'; 
    if (refs.quoteEditMode) refs.quoteEditMode.classList.add('active'); 
    var input = refs.quoteInput; 
    if (input) { input.value = appStore.currentQuote; input.focus(); } 
  }
  function saveQuote() { 
    var input = refs.quoteInput; 
    if (!input) return; 
    var value = input.value.trim(); 
    if (value) appStore.currentQuote = value; 
    syncQuoteUI(); 
    if (refs.quoteDisplayWrap) refs.quoteDisplayWrap.style.display = ''; 
    if (refs.quoteEditMode) refs.quoteEditMode.classList.remove('active'); 
    appStore.save(); 
    showToast('已保存一言'); 
  }
  function cancelQuoteEdit() { 
    if (refs.quoteDisplayWrap) refs.quoteDisplayWrap.style.display = ''; 
    if (refs.quoteEditMode) refs.quoteEditMode.classList.remove('active'); 
  }
  function syncQuoteUI() { 
    if (refs.quoteDisplay) refs.quoteDisplay.textContent = appStore.currentQuote; 
    requestAnimationFrame(checkQuoteScroll); 
  }

  function openFormModal(mode, context) {
    state.formState = { mode: mode, context: context }; 
    if (refs.formModal) refs.formModal.classList.add('active');
    if (refs.formTitle) refs.formTitle.textContent = mode === 'edit' ? '编辑项目' : '添加应用';
    if (mode === 'edit') {
      var item = appStore.getItemById(context.itemId); 
      if (!item) return;
      if (refs.formName) refs.formName.value = item.title || '';
      if (item.type === 'folder') { 
        if (refs.formUrlRow) refs.formUrlRow.style.display = 'none'; 
        if (refs.formIconRow) refs.formIconRow.style.display = 'none'; 
        if (refs.formBgColorRow) refs.formBgColorRow.style.display = 'none';
      }
      else { 
        if (refs.formUrlRow) refs.formUrlRow.style.display = ''; 
        if (refs.formIconRow) refs.formIconRow.style.display = ''; 
        if (refs.formBgColorRow) refs.formBgColorRow.style.display = ''; 
        if (refs.formUrl) refs.formUrl.value = item.url || ''; 
        if (refs.formIcon) refs.formIcon.value = item.icon || '';
        setSelectedBgStyle(item.bgStyle || PRESET_BG_COLORS[0].style);
      }
    } else {
      if (refs.formName) refs.formName.value = ''; 
      if (refs.formUrl) refs.formUrl.value = ''; 
      if (refs.formIcon) refs.formIcon.value = '';
      if (refs.formUrlRow) refs.formUrlRow.style.display = ''; 
      if (refs.formIconRow) refs.formIconRow.style.display = '';
      if (refs.formBgColorRow) refs.formBgColorRow.style.display = '';
      setSelectedBgStyle(PRESET_BG_COLORS[0].style);
    }
    updateFormPreview(); 
    if (refs.formName) refs.formName.focus();
  }
  function closeFormModal() { if (refs.formModal) refs.formModal.classList.remove('active'); state.formState = null; }
  function saveFormModal() {
    if (!state.formState) return; 
    var mode = state.formState.mode, context = state.formState.context, 
        name = refs.formName ? refs.formName.value.trim() : '', 
        url = refs.formUrl ? refs.formUrl.value.trim() : '', 
        icon = refs.formIcon ? refs.formIcon.value.trim() : '';
    if (!name) { showToast('请填写名称'); if (refs.formName) refs.formName.focus(); return; }
    if (mode === 'edit') {
      var item = appStore.getItemById(context.itemId); 
      if (!item) return;
      item.title = name; 
      if (item.type !== 'folder') { 
        item.url = url || '#'; 
        item.icon = icon || 'mdi:apps'; 
        var bgStyleValue = getSelectedBgStyle();
        if (!bgStyleValue) {
          bgStyleValue = PRESET_BG_COLORS[0].style;
        }
        var finalBgStyle;
        if (bgStyleValue.startsWith('background:')) {
          finalBgStyle = bgStyleValue;
        } else {
          finalBgStyle = 'background:' + bgStyleValue + ';';
        }
        item.bgStyle = finalBgStyle;
      }
      appStore.cleanupFolders(); 
      closeFormModal(); 
      renderEngine.renderAll(); 
      showToast('已保存'); 
      return;
    }
    var bgStyleValue = getSelectedBgStyle();
    if (!bgStyleValue) {
      bgStyleValue = PRESET_BG_COLORS[0].style;
    }
    var finalBgStyle;
    if (bgStyleValue.startsWith('background:')) {
      finalBgStyle = bgStyleValue;
    } else {
      finalBgStyle = 'background:' + bgStyleValue + ';';
    }
    var newItem = { id: generateId('app'), type: 'app', title: name, url: url || '#', icon: icon || 'mdi:apps', bgStyle: finalBgStyle };
    if (context && context.scope === 'folder' && context.folderId) { 
      appStore.insertFolderChild(context.folderId, newItem, Number.MAX_SAFE_INTEGER); 
      renderEngine.renderAll(); 
      renderEngine.renderFolderModal(); 
    }
    else if (context && context.scope === 'desktop' && typeof context.afterGlobalIndex === 'number') { 
      appStore.insertDesktopItem(newItem, context.afterGlobalIndex + 1); 
      renderEngine.renderAll(); 
    }
    else if (context && context.scope === 'desktop-blank') { 
      var insertAt = Math.min((appStore.currentPage + 1) * layoutStore.metrics.pageCapacity, appStore.desktop.items.length); 
      appStore.insertDesktopItem(newItem, insertAt); 
      renderEngine.renderAll(); 
    }
    else if (context && context.scope === 'dock') { 
      appStore.insertDockItem(newItem, appStore.dock.items.length); 
      renderEngine.renderAll(); 
    }
    else { 
      appStore.insertDesktopItem(newItem, appStore.desktop.items.length); 
      renderEngine.renderAll(); 
    }
    closeFormModal(); 
    showToast('已添加');
  }

  function getContextTargetFromElement(el) { 
    if (!el) return null; 
    var scope = el.dataset.scope; 
    if (scope === 'desktop' || scope === 'dock') return { kind: 'item', scope: scope, itemId: el.dataset.id }; 
    if (scope === 'folder') return { kind: 'item', scope: 'folder', folderId: el.dataset.folderId, itemId: el.dataset.id }; 
    return null; 
  }
  function hideContextMenu() { if (refs.contextMenu) refs.contextMenu.classList.remove('active'); state.contextTarget = null; }
  function showContextMenu(x, y, target) {
    state.contextTarget = target; 
    var isBlank = target && target.kind === 'blank';
    if (refs.ctxOpen) refs.ctxOpen.style.display = isBlank ? 'none' : ''; 
    if (refs.ctxDelete) refs.ctxDelete.style.display = isBlank ? 'none' : ''; 
    if (refs.ctxEdit) refs.ctxEdit.style.display = isBlank ? 'none' : ''; 
    if (refs.ctxAdd) refs.ctxAdd.style.display = ''; 
    if (refs.ctxWallpaper) refs.ctxWallpaper.style.display = '';
    if (refs.contextMenu) {
      refs.contextMenu.style.visibility = 'hidden'; 
      refs.contextMenu.style.left = '0'; 
      refs.contextMenu.style.top = '0'; 
      refs.contextMenu.classList.add('active');
      var menuRect = refs.contextMenu.getBoundingClientRect(), menuWidth = menuRect.width, menuHeight = menuRect.height, 
          viewportWidth = window.innerWidth, viewportHeight = window.innerHeight, safeMargin = 8;
      var left = x; 
      if (left + menuWidth > viewportWidth - safeMargin) left = Math.max(x - menuWidth, safeMargin); 
      else left = Math.max(left, safeMargin);
      var top = y; 
      if (top + menuHeight > viewportHeight - safeMargin) top = Math.max(y - menuHeight, safeMargin); 
      else top = Math.max(top, safeMargin);
      refs.contextMenu.style.left = left + 'px'; 
      refs.contextMenu.style.top = top + 'px'; 
      refs.contextMenu.style.visibility = 'visible';
      var firstItem = refs.contextMenu.querySelector('.context-item:not([style*="display: none"])'); 
      if (firstItem) firstItem.focus();
    }
    if (window.Iconify) { try { if (refs.contextMenu) Iconify.scan(refs.contextMenu); } catch (_) {} }
  }

  function openItem(item) {
    if (!item) return;
    if (item.type === 'folder') { appStore.folderModalId = item.id; renderEngine.renderFolderModal(); return; }
    if (item.url === '#sync' || item.id === 'app_sync') { openSyncModal(); return; }
    if (item.url && item.url !== '#') { window.open(item.url, '_blank'); return; }
    showToast('打开 ' + item.title);
  }
  function closeFolder() { appStore.folderModalId = null; if (refs.folderModal) refs.folderModal.classList.remove('active'); }

  // ==================== 全局引用 ====================
  var state = { contextTarget: null, formState: null, engineContextTarget: null, engineEditMode: false, engineEditId: null };
  var refs = {
    root: null, body: null, desktop: null, pagesContainer: null, indicators: null, dock: null, deleteZone: null,
    folderModal: null, folderTitle: null, folderGrid: null, folderEmpty: null, folderCloseBtn: null,
    contextMenu: null, ctxOpen: null, ctxEdit: null, ctxAdd: null, ctxDelete: null, ctxWallpaper: null,
    engineContextMenu: null, ctxEngineEdit: null, ctxEngineDelete: null,
    formModal: null, formTitle: null, formName: null, formUrl: null, formIcon: null, formUrlRow: null, formIconRow: null,
    formPreviewIcon: null, formPreviewName: null, formPreviewLink: null, formCloseBtn: null, formSaveBtn: null, formCancelBtn: null,
    engineFormModal: null, engineFormName: null, engineFormIcon: null, engineFormUrl: null, engineFormCloseBtn: null, engineFormCancelBtn: null, engineFormSaveBtn: null,
    engineIconSelectBtn: null, engineIconFileInput: null, engineIconPreviewRow: null, engineIconPreview: null,
    syncModal: null, syncCloseBtn: null, githubToken: null, githubRepo: null, syncIntervalSelect: null, syncPushBtn: null, syncPullBtn: null,
    wallpaperModal: null, wallpaperUrl: null, wallpaperFile: null, wallpaperCloseBtn: null, wallpaperSelectBtn: null, resetWallpaperBtn: null, applyWallpaperBtn: null,
    quoteText: null, quoteTextWrap: null, quoteEditBtn: null, quoteSaveBtn: null, quoteCancelBtn: null, quoteInput: null, quoteDisplayWrap: null, quoteEditMode: null,
    searchScreen: null, searchScreenInput: null, searchScreenEngineIcon: null, searchScreenEnginePanel: null, searchScreenEngineList: null, searchScreenBody: null, searchCloseBtn: null,
    engineIcon: null, enginePanel: null, engineList: null, iconSelectBtn: null, iconFileInput: null,
    syncStatusIcon: null, syncStatusTitle: null, syncStatusDesc: null, lastSyncInfo: null, nextSyncInfo: null
  };

  function resolveRefs() {
    function safeQuery(selector) { try { var el = document.querySelector(selector); return el; } catch(e) { return null; } }
    refs.root = document.documentElement; 
    refs.body = document.body; 
    refs.desktop = safeQuery('#desktop'); 
    refs.pagesContainer = safeQuery('#pagesContainer'); 
    refs.indicators = safeQuery('#pageIndicators'); 
    refs.dock = safeQuery('#dock'); 
    refs.deleteZone = safeQuery('#deleteZone');
    refs.folderModal = safeQuery('#folderModal'); 
    refs.folderTitle = safeQuery('#folderTitle'); 
    refs.folderGrid = safeQuery('#folderGrid'); 
    refs.folderEmpty = safeQuery('#folderEmpty'); 
    refs.folderCloseBtn = safeQuery('#folderCloseBtn');
    refs.contextMenu = safeQuery('#contextMenu'); 
    refs.ctxOpen = safeQuery('#ctxOpen'); 
    refs.ctxEdit = safeQuery('#ctxEdit'); 
    refs.ctxAdd = safeQuery('#ctxAdd'); 
    refs.ctxDelete = safeQuery('#ctxDelete'); 
    refs.ctxWallpaper = safeQuery('#ctxWallpaper');
    refs.engineContextMenu = safeQuery('#engineContextMenu');
    refs.ctxEngineEdit = safeQuery('#ctxEngineEdit');
    refs.ctxEngineDelete = safeQuery('#ctxEngineDelete');
    refs.formModal = safeQuery('#formModal'); 
    refs.formTitle = safeQuery('#formTitle'); 
    refs.formName = safeQuery('#formName'); 
    refs.formUrl = safeQuery('#formUrl'); 
    refs.formIcon = safeQuery('#formIcon'); 
    refs.formUrlRow = safeQuery('#formUrlRow'); 
    refs.formIconRow = safeQuery('#formIconRow');
    refs.formPreviewIcon = safeQuery('#formPreviewIcon');
    refs.formBgColorRow = safeQuery('#formBgColorRow'); 
    refs.formPreviewName = safeQuery('#formPreviewName'); 
    refs.formPreviewLink = safeQuery('#formPreviewLink'); 
    refs.formCloseBtn = safeQuery('#formCloseBtn'); 
    refs.formSaveBtn = safeQuery('#formSaveBtn'); 
    refs.formCancelBtn = safeQuery('#formCancelBtn');
    refs.engineFormModal = safeQuery('#engineFormModal'); 
    refs.engineFormName = safeQuery('#engineFormName'); 
    refs.engineFormIcon = safeQuery('#engineFormIcon'); 
    refs.engineFormUrl = safeQuery('#engineFormUrl'); 
    refs.engineFormCloseBtn = safeQuery('#engineFormCloseBtn'); 
    refs.engineFormCancelBtn = safeQuery('#engineFormCancelBtn'); 
    refs.engineFormSaveBtn = safeQuery('#engineFormSaveBtn');
    refs.engineIconSelectBtn = safeQuery('#engineIconSelectBtn');
    refs.engineIconFileInput = safeQuery('#engineIconFileInput');
    refs.engineIconPreviewRow = safeQuery('#engineIconPreviewRow');
    refs.engineIconPreview = safeQuery('#engineIconPreview');
    refs.syncModal = safeQuery('#syncModal'); 
    refs.syncCloseBtn = safeQuery('#syncCloseBtn'); 
    refs.githubToken = safeQuery('#githubToken'); 
    refs.githubRepo = safeQuery('#githubRepo'); 
    refs.syncIntervalSelect = safeQuery('#syncIntervalSelect'); 
    refs.syncPushBtn = safeQuery('#syncPushBtn'); 
    refs.syncPullBtn = safeQuery('#syncPullBtn');
    refs.wallpaperModal = safeQuery('#wallpaperModal'); 
    refs.wallpaperUrl = safeQuery('#wallpaperUrl'); 
    refs.wallpaperFile = safeQuery('#wallpaperFile'); 
    refs.wallpaperCloseBtn = safeQuery('#wallpaperCloseBtn'); 
    refs.wallpaperSelectBtn = safeQuery('#wallpaperSelectBtn'); 
    refs.resetWallpaperBtn = safeQuery('#resetWallpaperBtn'); 
    refs.applyWallpaperBtn = safeQuery('#applyWallpaperBtn');
    refs.quoteEditBtn = safeQuery('#quoteEditBtn'); 
    refs.quoteSaveBtn = safeQuery('#quoteSaveBtn'); 
    refs.quoteCancelBtn = safeQuery('#quoteCancelBtn'); 
    refs.quoteInput = safeQuery('#quoteInput'); 
    refs.quoteDisplayWrap = safeQuery('#quoteDisplayWrap'); 
    refs.quoteEditMode = safeQuery('#quoteEditMode');
    refs.searchScreen = safeQuery('#searchScreen'); 
    refs.searchScreenInput = safeQuery('#searchScreenInput'); 
    refs.searchScreenEngineIcon = safeQuery('#searchScreenEngineIcon'); 
    refs.searchScreenEnginePanel = safeQuery('#searchScreenEnginePanel'); 
    refs.searchScreenEngineList = safeQuery('#searchScreenEngineList'); 
    refs.searchScreenBody = safeQuery('#searchScreenBody'); 
    refs.searchCloseBtn = safeQuery('#searchCloseBtn');
    refs.engineIcon = safeQuery('#engineIcon'); 
    refs.enginePanel = safeQuery('#enginePanel'); 
    refs.iconSelectBtn = safeQuery('#iconSelectBtn'); 
    refs.iconFileInput = safeQuery('#iconFileInput');
    refs.syncStatusIcon = safeQuery('#syncStatusIcon'); 
    refs.syncStatusTitle = safeQuery('#syncStatusTitle');
    refs.syncStatusDesc = safeQuery('#syncStatusDesc');
    refs.engineFormTitle = safeQuery('#engineFormTitle');
    refs.lastSyncInfo = safeQuery('#lastSyncInfo');
    refs.nextSyncInfo = safeQuery('#nextSyncInfo');
    refs.quoteDisplay = safeQuery('#quoteDisplay');
    refs.bigTime = safeQuery('#bigTime');
    refs.headerDate = safeQuery('#headerDate');
    refs.bgColorModal = safeQuery('#bgColorModal');
    refs.bgColorSelectBtn = safeQuery('#bgColorSelectBtn');
    refs.bgColorPreview = safeQuery('#bgColorPreview');
  }

  // ==================== 事件绑定 ====================
  function bindEvents() {
    function safeBind(element, event, handler, options) { 
      if (element && element.addEventListener) { 
        element.addEventListener(event, handler, options); 
        return true; 
      } 
      return false; 
    }
    
    document.addEventListener('dragover', function documentDragoverHandler(e) { e.preventDefault(); e.stopPropagation(); }, { capture: true });
    document.addEventListener('drop', function documentDropHandler(e) { 
      e.preventDefault(); 
      e.stopPropagation(); 
      if (!dragStore.active) showToast('当前不支持该文件类型，请尝试其他文件'); 
    }, { capture: true });
    document.addEventListener('contextmenu', function documentContextmenuHandler(e) { 
      if (e.target.closest('.app-icon, .desktop, .dock, .folder-grid, .drag-ghost')) { 
        e.preventDefault(); 
        e.stopPropagation(); 
        return false; 
      } 
    }, { capture: true });
    document.addEventListener('dragstart', function documentDragstartHandler(e) { 
      if (e.target.closest('.app-icon, .folder-preview-cell, .form-preview-icon')) e.preventDefault(); 
    });
    
    document.addEventListener('error', function documentErrorHandler(e) {
      var target = e.target;
      if (target && target.tagName === 'IMG' && target.classList.contains('custom-icon')) {
        handleImageError(target);
      }
    }, { capture: true, passive: true });
    
    document.addEventListener('pointerdown', function documentPointerdownHandler(e) { dragStore.handlePointerDown(e); }, { passive: true });
    window.addEventListener('pointermove', function windowPointermoveHandler(e) { dragStore.handlePointerMove(e); }, { passive: false, capture: false });
    window.addEventListener('pointerup', function windowPointerupHandler(e) { dragStore.handlePointerUp(e); }, { passive: false });
    window.addEventListener('pointercancel', function windowPointercancelHandler() { 
      if (dragStore.originSnapshot) { 
        appStore.desktop.items = deepClone(dragStore.originSnapshot.desktop); 
        appStore.dock.items = deepClone(dragStore.originSnapshot.dock); 
        appStore.currentPage = dragStore.originSnapshot.currentPage; 
        appStore.folderModalId = dragStore.originSnapshot.folderModalId; 
        renderEngine.renderAll(); 
      } 
      dragStore.reset(); 
    }, { passive: false });
    document.addEventListener('visibilitychange', function documentVisibilitychangeHandler() { 
      if (document.visibilityState === 'hidden' && dragStore.active) { 
        if (dragStore.originSnapshot) { 
          appStore.desktop.items = deepClone(dragStore.originSnapshot.desktop); 
          appStore.dock.items = deepClone(dragStore.originSnapshot.dock); 
          appStore.currentPage = dragStore.originSnapshot.currentPage; 
          appStore.folderModalId = dragStore.originSnapshot.folderModalId; 
        } 
        dragStore.reset(); 
        renderEngine.renderAll(); 
      } 
    });
    
    document.addEventListener('click', function documentClickHandler(e) {
      var iconEl = e.target.closest('.app-icon[data-id]');
      if (iconEl) { 
        if (dragStore.active || dragStore.contextTriggered) { dragStore.contextTriggered = false; return; } 
        e.stopPropagation(); 
        var item = appStore.getItemById(iconEl.dataset.id); 
        if (item) openItem(item); 
        dragStore.contextTriggered = false; 
        return; 
      }
      var isInteractive = e.target.closest('input, button, textarea, label, a, .context-menu, .engine-panel, .quote-edit-btn, .quote-action-btn, .search-icon, [role="button"]:not(.app-icon [role="button"]), [role="tab"]');
      var isFormActive = refs.formModal && refs.formModal.classList.contains('active'), 
          isWallpaperActive = refs.wallpaperModal && refs.wallpaperModal.classList.contains('active'), 
          isEngineFormActive = refs.engineFormModal && refs.engineFormModal.classList.contains('active'), 
          isSyncActive = refs.syncModal && refs.syncModal.classList.contains('active'), 
          isSearchActive = refs.searchScreen && refs.searchScreen.classList.contains('active');
      if (dragStore.active || dragStore.contextTriggered || isFormActive || isWallpaperActive || isEngineFormActive || isSyncActive || isSearchActive || isInteractive) { 
        dragStore.contextTriggered = false; 
        return; 
      }
    });
    
    document.addEventListener('keydown', function documentKeydownHandler(e) {
      if (e.key === 'Escape') {
        var isSearchActive = refs.searchScreen && refs.searchScreen.classList.contains('active'); 
        if (isSearchActive) { closeSearchScreen(); return; }
        var isBgColorActive = refs.bgColorModal && refs.bgColorModal.classList.contains('active');
        if (isBgColorActive) { closeBgColorModal(); return; }
        closeFolder();
        hideContextMenu();
        hideEngineContextMenu();
        closeFormModal();
        closeWallpaperModal();
        closeEngineFormModal();
        closeSyncModal();
        var enginePanel = document.getElementById('enginePanel'); 
        if (enginePanel) enginePanel.classList.remove('active');
        if (dragStore.active) { 
          if (dragStore.originSnapshot) { 
            appStore.desktop.items = deepClone(dragStore.originSnapshot.desktop); 
            appStore.dock.items = deepClone(dragStore.originSnapshot.dock); 
            appStore.currentPage = dragStore.originSnapshot.currentPage; 
            appStore.folderModalId = dragStore.originSnapshot.folderModalId; 
            renderEngine.renderAll(); 
          } 
          dragStore.reset(); 
        }
        return;
      }
      if (e.key === 'Delete' && document.activeElement && document.activeElement.classList.contains('app-icon')) { 
        var itemId = document.activeElement.dataset.id; 
        if (itemId && confirm('确定删除此项目吗？')) { 
          appStore.deleteItemById(itemId); 
          closeFolder(); 
          renderEngine.renderAll(); 
          showToast('已删除'); 
        } 
        return; 
      }
      var isSearchActive = refs.searchScreen && refs.searchScreen.classList.contains('active');
      if (e.key === 'ArrowLeft' && appStore.currentPage > 0 && !isSearchActive) { 
        e.preventDefault(); 
        pageManager.turnTo(appStore.currentPage - 1); 
      }
      if (e.key === 'ArrowRight' && appStore.currentPage < appStore.getPageCount() - 1 && !isSearchActive) { 
        e.preventDefault(); 
        pageManager.turnTo(appStore.currentPage + 1); 
      }
      if (e.key === ' ' && document.activeElement && document.activeElement.classList.contains('app-icon')) { 
        e.preventDefault(); 
        var activeIcon = document.activeElement, context = getContextTargetFromElement(activeIcon); 
        if (context) showContextMenu(0, 0, context); 
      }
    });
    
    if (refs.indicators) {
      refs.indicators.addEventListener('click', function indicatorsClickHandler(e) { 
        var dot = e.target.closest('[data-page]'); 
        if (!dot) return; 
        var page = clamp(Number(dot.dataset.page) || 0, 0, appStore.getPageCount() - 1); 
        pageManager.turnTo(page); 
      });
      refs.indicators.addEventListener('keydown', function indicatorsKeydownHandler(e) { 
        if (e.key === 'Enter' || e.key === ' ') { 
          var dot = e.target.closest('[data-page]'); 
          if (dot) { 
            e.preventDefault(); 
            var page = clamp(Number(dot.dataset.page) || 0, 0, appStore.getPageCount() - 1); 
            pageManager.turnTo(page); 
          } 
        } 
      });
    }
    
    safeBind(refs.ctxOpen, 'click', function ctxOpenClickHandler() {
      if (!state.contextTarget || state.contextTarget.kind !== 'item') return;
      var item = appStore.getItemById(state.contextTarget.itemId);
      hideContextMenu();
      openItem(item);
    });
    safeBind(refs.ctxEngineEdit, 'click', function ctxEngineEditClickHandler() {
      openEngineEditModal();
    });
    safeBind(refs.ctxEngineDelete, 'click', function ctxEngineDeleteClickHandler() {
      deleteEngineFromContextMenu();
    });
    safeBind(refs.ctxEdit, 'click', function ctxEditClickHandler() { 
      if (!state.contextTarget || state.contextTarget.kind !== 'item') return; 
      var targetContext = Object.assign({}, state.contextTarget); 
      hideContextMenu(); 
      openFormModal('edit', targetContext); 
    });
    safeBind(refs.ctxAdd, 'click', function ctxAddClickHandler() { 
      var ctx = state.contextTarget; 
      hideContextMenu(); 
      if (!ctx) { openFormModal('add', { scope: 'desktop-blank' }); return; } 
      if (ctx.kind === 'blank') { openFormModal('add', { scope: 'desktop-blank' }); return; } 
      if (ctx.scope === 'desktop') { 
        var loc = appStore.locateItem(ctx.itemId); 
        openFormModal('add', { scope: 'desktop', afterGlobalIndex: loc && loc.globalIndex !== undefined ? loc.globalIndex : appStore.desktop.items.length - 1 }); 
        return; 
      } 
      if (ctx.scope === 'dock') { openFormModal('add', { scope: 'dock' }); return; } 
      if (ctx.scope === 'folder') { openFormModal('add', { scope: 'folder', folderId: ctx.folderId }); } 
    });
    safeBind(refs.ctxDelete, 'click', function ctxDeleteClickHandler() { 
      if (!state.contextTarget || state.contextTarget.kind !== 'item') return; 
      var item = appStore.getItemById(state.contextTarget.itemId); 
      if (!item) return; 
      if (!confirm('确定删除"' + (item.title || '该项目') + '"吗？')) return; 
      appStore.deleteItemById(state.contextTarget.itemId); 
      closeFolder(); 
      hideContextMenu(); 
      renderEngine.renderAll(); 
      showToast('已删除'); 
    });
    safeBind(refs.ctxWallpaper, 'click', function ctxWallpaperClickHandler() { 
      hideContextMenu(); 
      if (refs.wallpaperModal) refs.wallpaperModal.classList.add('active'); 
    });
    
    safeBind(refs.formName, 'input', updateFormPreview); 
    safeBind(refs.formUrl, 'input', updateFormPreview); 
    safeBind(refs.formIcon, 'input', updateFormPreview);
    safeBind(document.getElementById('bgColorSelectBtn'), 'click', openBgColorModal);
    safeBind(document.getElementById('bgColorModalCloseBtn'), 'click', closeBgColorModal);
    safeBind(document.getElementById('bgColorCancelBtn'), 'click', closeBgColorModal);
    safeBind(document.getElementById('bgColorConfirmBtn'), 'click', confirmBgColorSelection);
    safeBind(document.getElementById('bgColorApplyBtn'), 'click', applyCustomBgColorInModal);
    safeBind(refs.formCloseBtn, 'click', closeFormModal); 
    safeBind(refs.formCancelBtn, 'click', closeFormModal); 
    safeBind(refs.formSaveBtn, 'click', saveFormModal);
    
    safeBind(refs.githubToken, 'blur', function githubTokenBlurHandler(e) { 
      var token = e.target.value.trim(); 
      if (token && token !== syncStore.config.token) syncStore.validateToken(token); 
    });
    safeBind(refs.githubRepo, 'change', function githubRepoChangeHandler(e) { 
      syncStore.config.repo = e.target.value.trim(); 
      syncStore.save(); 
    });
    if (refs.syncIntervalSelect) refs.syncIntervalSelect.addEventListener('change', handleSyncIntervalChange);
    
    safeBind(refs.syncPushBtn, 'click', manualPushToGithub); 
    safeBind(refs.syncPullBtn, 'click', manualPullFromGithub); 
    safeBind(refs.syncCloseBtn, 'click', closeSyncModal);
    
    safeBind(refs.quoteEditBtn, 'click', editQuote); 
    safeBind(refs.quoteSaveBtn, 'click', saveQuote); 
    safeBind(refs.quoteCancelBtn, 'click', cancelQuoteEdit);
    
    safeBind(refs.wallpaperCloseBtn, 'click', closeWallpaperModal);
    safeBind(refs.wallpaperSelectBtn, 'click', function wallpaperSelectBtnHandler() { if (refs.wallpaperFile) refs.wallpaperFile.click(); });
    if (refs.wallpaperFile) refs.wallpaperFile.addEventListener('change', function wallpaperFileHandler(e) { 
      var file = e.target.files[0]; 
      if (!file) return; 
      var reader = new FileReader(); 
      reader.onload = function wallpaperReaderHandler(ev) { if (refs.wallpaperUrl) refs.wallpaperUrl.value = ev.target.result; }; 
      reader.readAsDataURL(file); 
    });
    safeBind(refs.applyWallpaperBtn, 'click', function applyWallpaperBtnHandler() { 
      if (!refs.wallpaperUrl) return; 
      var url = refs.wallpaperUrl.value.trim(); 
      if (url) { applyWallpaper(url); closeWallpaperModal(); return; } 
      showToast('请输入图片URL或选择图片'); 
    });
    safeBind(refs.resetWallpaperBtn, 'click', function resetWallpaperBtnHandler() { resetWallpaper(); closeWallpaperModal(); });
    
    safeBind(refs.iconSelectBtn, 'click', function iconSelectBtnHandler() { if (refs.iconFileInput) refs.iconFileInput.click(); });
    if (refs.iconFileInput) refs.iconFileInput.addEventListener('change', function iconFileInputHandler(e) { 
      var file = e.target.files[0]; 
      if (!file) return; 
      var reader = new FileReader(); 
      reader.onload = function iconReaderOnload(ev) { if (refs.formIcon) refs.formIcon.value = ev.target.result; updateFormPreview(); }; 
      reader.readAsDataURL(file); 
    });
    document.addEventListener('click', function modalOverlayClickHandler(e) {
      if (e.target === refs.folderModal) { closeFolder(); return; }
      if (!e.target.closest('.context-menu') && !e.target.closest('.app-icon')) hideContextMenu();
      if (!e.target.closest('#engineContextMenu') && !e.target.closest('.engine-item')) hideEngineContextMenu();
      if (!e.target.closest('.search-icon') && !e.target.closest('.engine-panel')) { 
        var enginePanel = document.getElementById('enginePanel'); 
        if (enginePanel) enginePanel.classList.remove('active'); 
      }
      if (!e.target.closest('#searchScreenEngineIcon') && !e.target.closest('#searchScreenEnginePanel')) { 
        var searchEnginePanel = document.getElementById('searchScreenEnginePanel'); 
        if (searchEnginePanel) searchEnginePanel.classList.remove('active'); 
      }
      if (e.target === refs.formModal) closeFormModal();
      if (e.target === refs.syncModal) closeSyncModal();
      if (e.target === refs.wallpaperModal) closeWallpaperModal();
      if (e.target === refs.bgColorModal) closeBgColorModal();
    }, { passive: true });
    
    var blankClickTimer = null;
    document.addEventListener('click', function blankClickHandler(e) {
      var isAnyModalActive = (refs.folderModal && refs.folderModal.classList.contains('active')) || 
                             (refs.formModal && refs.formModal.classList.contains('active')) || 
                             (refs.contextMenu && refs.contextMenu.classList.contains('active')) || 
                             (refs.wallpaperModal && refs.wallpaperModal.classList.contains('active')) || 
                             (refs.engineFormModal && refs.engineFormModal.classList.contains('active')) || 
                             (refs.syncModal && refs.syncModal.classList.contains('active')) || 
                             (refs.searchScreen && refs.searchScreen.classList.contains('active'));
      if (isAnyModalActive) return;
      var interactive = e.target.closest('.app-icon, .dock, .top-actions, .search-bar, .quote-edit-btn, .quote-action-btn, .page-indicators, .delete-zone');
      if (interactive) return; 
      if (!refs.desktop || !refs.desktop.contains(e.target)) return; 
      if (blankClickTimer) return;
      var clickX = e.clientX, screenWidth = window.innerWidth;
      if (clickX < screenWidth / 2) { 
        if (appStore.currentPage > 0) pageManager.turnTo(appStore.currentPage - 1); 
      } else { 
        if (appStore.currentPage < appStore.getPageCount() - 1) pageManager.turnTo(appStore.currentPage + 1); 
      }
      blankClickTimer = setTimeout(function blankClickTimeout() { blankClickTimer = null; }, 300);
    });
    
    safeBind(refs.folderCloseBtn, 'click', closeFolder);
    safeBind(refs.engineFormCloseBtn, 'click', closeEngineFormModal); 
    safeBind(refs.engineFormCancelBtn, 'click', closeEngineFormModal); 
    safeBind(refs.engineFormSaveBtn, 'click', saveCustomEngine);

    safeBind(refs.engineIconSelectBtn, 'click', function engineIconSelectBtnHandler() {
      if (refs.engineIconFileInput) refs.engineIconFileInput.click();
    });
    if (refs.engineIconFileInput) {
      refs.engineIconFileInput.addEventListener('change', function engineIconFileInputHandler(e) {
        var file = e.target.files && e.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function engineIconReaderOnload(ev) {
          var dataUrl = ev.target.result;
          if (refs.engineFormIcon) refs.engineFormIcon.value = dataUrl;
          updateEngineIconPreview(dataUrl);
        };
        reader.readAsDataURL(file);
      });
    }
    safeBind(refs.engineFormIcon, 'input', function engineFormIconInputHandler() {
      var val = refs.engineFormIcon ? refs.engineFormIcon.value.trim() : '';
      updateEngineIconPreview(val);
    });
    safeBind(refs.searchCloseBtn, 'click', closeSearchScreen);
    
    document.addEventListener('click', function engineIconClickHandler(e) {
      var engineIcon = e.target.closest('#engineIcon');
      if (engineIcon) {
        e.preventDefault();
        e.stopPropagation();
        toggleEnginePanel();
        return;
      }
      var searchScreenEngineIcon = e.target.closest('#searchScreenEngineIcon');
      if (searchScreenEngineIcon) {
        e.preventDefault();
        e.stopPropagation();
        toggleSearchScreenEnginePanel();
        return;
      }
    });
    
    if (refs.searchScreenBody) {
      refs.searchScreenBody.addEventListener('click', function suggestClickHandler(e) {
        var clearHistoryBtn = e.target.closest('[data-action="clear-history"]');
        if (clearHistoryBtn) { 
          searchStore.clearHistory(); 
          showToast('搜索历史已清除'); 
          e.stopPropagation();
          e.preventDefault();
          return;
        }

        var arrowBtn = e.target.closest('.suggest-arrow');
        if (arrowBtn) {
          var text = arrowBtn.dataset.text;
          var action = arrowBtn.dataset.suggestAction;
          if (action === 'remove') {
            searchStore.removeHistoryItem(text);
          } else if (text && refs.searchScreenInput) {
            refs.searchScreenInput.value = text;
            refs.searchScreenInput.focus();
            refs.searchScreenInput.setSelectionRange(text.length, text.length);
          }
          e.stopPropagation();
          e.preventDefault();
          return;
        }

        var suggestItem = e.target.closest('.suggest-item');
        if (suggestItem) {
          var text = suggestItem.dataset.text;
          if (text) {
            searchStore.addHistory(text);
            handleSearchOrUrl(text, searchStore.currentEngine);
            closeSearchScreen();
          }
          e.stopPropagation();
          return;
        }
      });
    }
    
    if (refs.enginePanel) {
      refs.enginePanel.addEventListener('click', function enginePanelClickHandler(e) {
        if (engineLongPressState.isLongPress) return;
        var engineItem = e.target.closest('.engine-item[data-engine-id]');
        if (engineItem) { var engineId = engineItem.dataset.engineId; switchEngine(engineId); }
        var addBtn = e.target.closest('[data-action="add-engine"]');
        if (addBtn) openEngineFormModal();
      });
    }
    
    if (refs.searchScreenEnginePanel) {
      refs.searchScreenEnginePanel.addEventListener('click', function searchEnginePanelClickHandler(e) {
        if (engineLongPressState.isLongPress) return;
        var engineItem = e.target.closest('.engine-item[data-engine-id]');
        if (engineItem) { var engineId = engineItem.dataset.engineId; switchEngine(engineId); }
        var addBtn = e.target.closest('[data-action="add-engine"]');
        if (addBtn) openEngineFormModal();
      });
    }
    
    // 绑定风格切换事件
    bindStyleToggleEvents();
  }

  // ==================== 页面滑动 ====================
  function setupPageSwipe() {
    var startX = 0, startY = 0, tracking = false; 
    if (!refs.desktop) return;
    refs.desktop.addEventListener('pointerdown', function swipePointerdownHandler(e) { 
      if (e.target.closest('.app-icon')) return; 
      startX = e.clientX; 
      startY = e.clientY; 
      tracking = true; 
    }, { passive: true });
    refs.desktop.addEventListener('pointerup', function swipePointerupHandler(e) { 
      if (!tracking || dragStore.active) return; 
      tracking = false; 
      var dx = e.clientX - startX, dy = e.clientY - startY; 
      if (Math.abs(dx) < 36 || Math.abs(dy) > Math.abs(dx) * 0.8) return; 
      if (dx < 0 && appStore.currentPage < appStore.getPageCount() - 1) pageManager.turnTo(appStore.currentPage + 1); 
      else if (dx > 0 && appStore.currentPage > 0) pageManager.turnTo(appStore.currentPage - 1); 
    }, { passive: false });
  }

  // ==================== 时间更新 ====================
  function updateTime() { 
    if (!refs.bigTime) return; 
    var now = new Date(), h = String(now.getHours()).padStart(2, '0'), m = String(now.getMinutes()).padStart(2, '0'); 
    refs.bigTime.textContent = h + ':' + m; 
  }
  function updateDate() { 
    if (!refs.headerDate) return; 
    var now = new Date(), weekdays = ['星期日','星期一','星期二','星期三','星期四','星期五','星期六']; 
    refs.headerDate.textContent = (now.getMonth() + 1) + '月' + now.getDate() + '日 ' + weekdays[now.getDay()]; 
  }

  // ==================== 图标背景色功能 ====================
  var selectedBgColor = PRESET_BG_COLORS[0].style;
  var tempSelectedBgColor = PRESET_BG_COLORS[0].style;

  function openBgColorModal() {
    var modal = document.getElementById('bgColorModal');
    if (!modal) return;
    tempSelectedBgColor = selectedBgColor;
    renderBgColorGrid();
    updateBgColorPreview();
    modal.classList.add('active');
  }

  function closeBgColorModal() {
    var modal = document.getElementById('bgColorModal');
    if (modal) modal.classList.remove('active');
  }

  function renderBgColorGrid() {
    var grid = document.getElementById('bgColorModalGrid');
    if (!grid) return;
    grid.innerHTML = '';
    PRESET_BG_COLORS.forEach(function renderBgColorEach(color, index) {
      var item = document.createElement('div');
      item.className = 'bg-color-item';
      item.style.background = color.style;
      item.dataset.index = index;
      item.dataset.style = color.style;
      item.title = color.name;
      if (color.style === tempSelectedBgColor) {
        item.classList.add('selected');
      }
      item.addEventListener('click', function bgColorItemClickHandler() {
        selectBgColorInModal(color.style, item);
      });
      grid.appendChild(item);
    });
  }

  function selectBgColorInModal(style, element) {
    tempSelectedBgColor = style;
    var grid = document.getElementById('bgColorModalGrid');
    if (grid) {
      querySelectorAll('.bg-color-item', grid).forEach(function removeSelectedClass(el) {
        el.classList.remove('selected');
      });
    }
    if (element) element.classList.add('selected');
    var customInput = document.getElementById('bgColorCustomInput');
    if (customInput) {
      var hexColorPattern = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
      if (hexColorPattern.test(style)) {
        customInput.value = style;
      } else {
        customInput.value = '';
      }
    }
  }

  function applyCustomBgColorInModal() {
    var input = document.getElementById('bgColorCustomInput');
    if (!input) return;
    var value = input.value.trim();
    if (!value) {
      showToast('请输入CSS渐变代码或16进制颜色');
      return;
    }
    
    var finalValue;
    var hexColorPattern = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
    if (hexColorPattern.test(value)) {
      finalValue = value;
    } else if (value.toLowerCase().includes('gradient') || value.includes('rgb') || value.includes('hsl') || /^[a-zA-Z]+$/.test(value)) {
      finalValue = value;
    } else {
      showToast('请输入有效的CSS颜色值(如#ff0000)或渐变代码');
      return;
    }
    
    tempSelectedBgColor = finalValue;
    var grid = document.getElementById('bgColorModalGrid');
    if (grid) {
      querySelectorAll('.bg-color-item', grid).forEach(function removeSelected(el) {
        el.classList.remove('selected');
      });
    }
    showToast('已应用自定义颜色');
  }

  function confirmBgColorSelection() {
    selectedBgColor = tempSelectedBgColor;
    updateBgColorPreview();
    updateFormPreview();
    closeBgColorModal();
  }

  function updateBgColorPreview() {
    var preview = document.getElementById('bgColorPreview');
    if (preview) preview.style.background = selectedBgColor;
  }

  function getSelectedBgStyle() {
    return selectedBgColor || PRESET_BG_COLORS[0].style;
  }

  function setSelectedBgStyle(style) {
    var cleanStyle = style;
    if (style && style.startsWith('background:')) {
      cleanStyle = style.replace(/^background:\s*/, '').replace(/;\s*$/, '');
    }
    
    var hexColorPattern = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
    
    if (hexColorPattern.test(cleanStyle)) {
      selectedBgColor = cleanStyle;
    } else if (cleanStyle && (cleanStyle.includes('gradient') || cleanStyle.includes('rgb') || cleanStyle.includes('hsl') || /^[a-zA-Z]+$/.test(cleanStyle))) {
      selectedBgColor = cleanStyle;
    } else {
      selectedBgColor = cleanStyle || PRESET_BG_COLORS[0].style;
    }
    
    tempSelectedBgColor = selectedBgColor;
    updateBgColorPreview();
  }

  function updateFormPreview() {
    var name = refs.formName && refs.formName.value ? refs.formName.value.trim() : '应用预览', 
        url = refs.formUrl && refs.formUrl.value ? refs.formUrl.value.trim() : 'https://example.com', 
        icon = refs.formIcon && refs.formIcon.value ? refs.formIcon.value.trim() : 'mdi:apps';
    if (refs.formPreviewName) refs.formPreviewName.textContent = name; 
    if (refs.formPreviewLink) refs.formPreviewLink.textContent = url;
    if (refs.formPreviewIcon) { 
  if (isImageIcon(icon)) refs.formPreviewIcon.innerHTML = '<img src="' + escapeHtml(icon) + '" alt="" loading="lazy" decoding="async">'; 
  else refs.formPreviewIcon.innerHTML = '<span class="iconify" data-icon="' + escapeHtml(icon) + '" style="color: white;"></span>'; 
  var bgStyle = getSelectedBgStyle();
  refs.formPreviewIcon.style.background = bgStyle;
}
    if (window.Iconify && refs.formPreviewIcon) { try { Iconify.scan(refs.formPreviewIcon); } catch (_) {} }
  }

  // ==================== 初始化 ====================
  function init() {
    try {
      storageAdapter.checkExtensionEnvironment();
      resolveRefs();
      
      // 先初始化风格（必须在其他UI初始化之前）
      initStyle();
      
      dragStore.init();
      syncStore.load();
      layoutStore.init();
      
      // 根据当前风格加载壁纸（毛玻璃风格才加载）
      if (currentStyle === 'glass') {
        loadWallpaperForGlass();
      }
      
      setupSearch();
      setupPageSwipe();
      searchStore.loadCustomEngines().then(function loadEnginesThen() {
        appStore.load();
      }).catch(function loadEnginesCatch() {
        appStore.load();
      });
      updateTime(); 
      updateDate();
      setInterval(updateTime, 1000);
      setInterval(updateDate, 60000);
      bindEvents();
      if (window.Iconify) { try { Iconify.scan(document.body); } catch (_) {} }
      window.addEventListener('load', function windowLoadHandler() { 
        layoutStore.refresh(); 
        if (window.Iconify) Iconify.scan(document.body); 
      });
      window.addEventListener('orientationchange', function orientationchangeHandler() { 
        setTimeout(function orientationTimeout() { layoutStore.refresh(); }, 100); 
      });
    } catch (error) { showToast('初始化失败: ' + error.message); }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); 
  else init();
})();