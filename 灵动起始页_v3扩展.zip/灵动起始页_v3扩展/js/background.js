/**
 * 灵动起始页 - Background Script
 * 处理右键菜单、网页剪藏功能
 */

// 存储键名
const STORAGE_KEY = 'xs_desktop_final_v2';

// 初始化扩展
chrome.runtime.onInstalled.addListener((details) => {
  console.log('[灵动起始页] 扩展已安装/更新');
  
  // 创建右键菜单
  createContextMenus();
});

// 创建右键菜单
function createContextMenus() {
  chrome.contextMenus.removeAll(() => {
    // 主菜单项
    chrome.contextMenus.create({
      id: 'addToStartPage',
      title: '添加到灵动起始页',
      contexts: ['page', 'link'],
      documentUrlPatterns: ['http://*/*', 'https://*/*']
    });
    
    // 子菜单：快速添加
    chrome.contextMenus.create({
      id: 'quickAdd',
      parentId: 'addToStartPage',
      title: '快速添加',
      contexts: ['page', 'link']
    });
    
    // 子菜单：添加并编辑
    chrome.contextMenus.create({
      id: 'addAndEdit',
      parentId: 'addToStartPage',
      title: '添加并编辑...',
      contexts: ['page', 'link']
    });
  });
}

// 处理右键菜单点击
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  console.log('[灵动起始页] 菜单点击:', info.menuItemId, tab.url);
  
  try {
    switch (info.menuItemId) {
      case 'quickAdd':
        await clipPage(tab, { mode: 'quick' });
        break;
      case 'addAndEdit':
        await clipPage(tab, { mode: 'edit' });
        break;
      case 'addToStartPage':
        await clipPage(tab, { mode: 'quick' });
        break;
    }
  } catch (error) {
    console.error('[灵动起始页] 剪藏失败:', error);
    showNotification('剪藏失败', error.message);
  }
});

// 核心剪藏功能
async function clipPage(tab, options = {}) {
  const { mode = 'quick' } = options;
  
  // 检查是否是起始页本身
  if (isStartPage(tab.url)) {
    showNotification('提示', '当前页面已经是起始页了');
    return;
  }
  
  // 1. 获取页面基本信息
  const pageInfo = await getPageInfo(tab);
  
  // 2. 获取网站图标
  pageInfo.favicon = await getFavicon(tab, pageInfo);
  
  // 3. 生成应用数据
  const appData = createAppData(pageInfo);
  
  // 4. 保存到存储
  await saveAppToStorage(appData);
  
  // 5. 通知所有起始页标签
  notifyStartPages('appAdded', appData);
  
  // 6. 显示通知
  showNotification('剪藏成功', `已添加 "${appData.title}" 到起始页`);
  
  // 7. 如果需要编辑，打开起始页并进入编辑模式
  if (mode === 'edit') {
    await openStartPageWithEdit(appData);
  }
}

// 获取页面信息
async function getPageInfo(tab) {
  return new Promise((resolve) => {
    // 执行内容脚本获取页面信息
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageInfo
    }, (results) => {
      if (chrome.runtime.lastError) {
        resolve({
          title: tab.title || '未命名页面',
          url: tab.url,
          description: '',
          favicon: ''
        });
        return;
      }
      
      if (results && results[0] && results[0].result) {
        resolve(results[0].result);
      } else {
        resolve({
          title: tab.title || '未命名页面',
          url: tab.url,
          description: '',
          favicon: ''
        });
      }
    });
  });
}

// 在页面中执行的函数
function extractPageInfo() {
  const doc = document;
  
  // 获取标题
  let title = doc.title || '未命名页面';
  const ogTitle = doc.querySelector('meta[property="og:title"]');
  if (ogTitle && ogTitle.content) {
    title = ogTitle.content.trim();
  }
  
  // 获取描述
  let description = '';
  const ogDesc = doc.querySelector('meta[property="og:description"]');
  const metaDesc = doc.querySelector('meta[name="description"]');
  if (ogDesc && ogDesc.content) {
    description = ogDesc.content.trim();
  } else if (metaDesc && metaDesc.content) {
    description = metaDesc.content.trim();
  }
  
  // 获取图标
  let favicon = '';
  const selectors = [
    'link[rel="apple-touch-icon"]',
    'link[rel="icon"][type="image/png"]',
    'link[rel="icon"]',
    'link[rel="shortcut icon"]'
  ];
  for (const selector of selectors) {
    const link = doc.querySelector(selector);
    if (link && link.href) {
      favicon = link.href;
      break;
    }
  }
  
  return {
    title: title,
    url: window.location.href,
    description: description,
    favicon: favicon,
    domain: window.location.hostname
  };
}

// 获取网站图标
async function getFavicon(tab, pageInfo) {
  if (pageInfo.favicon) {
    return pageInfo.favicon;
  }
  
  // 使用 Google 的 favicon 服务
  const url = new URL(tab.url);
  return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(url.hostname)}&sz=128`;
}

// 生成应用数据
function createAppData(pageInfo) {
  const id = 'app_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  
  // 随机渐变背景色
  const gradients = [
    'linear-gradient(135deg,#4f86ff,#2f5fff)',
    'linear-gradient(135deg,#00c6ff,#0072ff)',
    'linear-gradient(135deg,#232526,#414345)',
    'linear-gradient(135deg,#ff4b2b,#ff416c)',
    'linear-gradient(135deg,#00b09b,#96c93d)',
    'linear-gradient(135deg,#ff7a18,#ffb347)',
    'linear-gradient(135deg,#4facfe,#00f2fe)',
    'linear-gradient(135deg,#667eea,#764ba2)',
    'linear-gradient(135deg,#f7971e,#ffd200)',
    'linear-gradient(135deg,#43cea2,#185a9d)',
    'linear-gradient(135deg,#fc4a1a,#f7b733)',
    'linear-gradient(135deg,#11998e,#38ef7d)',
    'linear-gradient(135deg,#ff5f6d,#ffc371)',
    'linear-gradient(135deg,#396afc,#2948ff)',
    'linear-gradient(135deg,#1d4350,#a43931)',
    'linear-gradient(135deg,#56ab2f,#a8e063)',
    'linear-gradient(135deg,#2193b0,#6dd5ed)',
    'linear-gradient(135deg,#7f00ff,#e100ff)',
    'linear-gradient(135deg,#8e2de2,#4a00e0)',
    'linear-gradient(135deg,#f4c4f3,#fc67fa)'
  ];
  const randomGradient = gradients[Math.floor(Math.random() * gradients.length)];
  
  return {
    id: id,
    type: 'app',
    title: truncateTitle(pageInfo.title),
    url: pageInfo.url,
    icon: pageInfo.favicon || '',
    bgStyle: 'background:' + randomGradient + ';',
    description: pageInfo.description || '',
    clippedAt: Date.now()
  };
}

// 截断标题
function truncateTitle(title, maxLength = 6) {
  if (!title) return '未命名';
  if (title.length <= maxLength) return title;
  return title.substring(0, maxLength);
}

// 保存应用到存储
async function saveAppToStorage(appData) {
  const result = await chrome.storage.local.get([STORAGE_KEY]);
  let data = result[STORAGE_KEY] ? JSON.parse(result[STORAGE_KEY]) : getDefaultData();
  
  // 检查是否已存在相同URL
  const existingIndex = data.desktop.items.findIndex(item => item.url === appData.url);
  if (existingIndex >= 0) {
    data.desktop.items[existingIndex] = appData;
  } else {
    data.desktop.items.push(appData);
  }
  
  await chrome.storage.local.set({
    [STORAGE_KEY]: JSON.stringify(data)
  });
}

// 获取默认数据
function getDefaultData() {
  return {
    currentPage: 0,
    currentQuote: '生活不是等待风暴过去，而是学会在雨中跳舞。',
    desktop: { items: [] },
    dock: { 
      id: 'dock', 
      capacity: 6, 
      items: [
        { id: 'dock_phone', type: 'app', title: '电话', url: 'https://www.google.com/search?q=%E7%94%B5%E8%AF%9D', icon: 'mdi:phone-outline', bgStyle: 'background:linear-gradient(135deg,#00c853,#43a047);' },
        { id: 'dock_message', type: 'app', title: '消息', url: 'https://mail.qq.com', icon: 'mdi:message-outline', bgStyle: 'background:linear-gradient(135deg,#36d1dc,#5b86e5);' },
        { id: 'dock_browser', type: 'app', title: '浏览器', url: 'https://www.google.com', icon: 'mdi:web', bgStyle: 'background:linear-gradient(135deg,#f7971e,#ffd200);' },
        { id: 'dock_album', type: 'app', title: '相册', url: 'https://image.baidu.com', icon: 'mdi:image-outline', bgStyle: 'background:linear-gradient(135deg,#ff512f,#dd2476);' }
      ] 
    }
  };
}

// 通知所有起始页标签
async function notifyStartPages(action, data) {
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('index.html') + '*' });
  for (const tab of tabs) {
    chrome.tabs.sendMessage(tab.id, { action, data }).catch(() => {});
  }
}

// 打开起始页并进入编辑模式
async function openStartPageWithEdit(appData) {
  // 存储待编辑数据
  await chrome.storage.local.set({ 'pendingEditApp': appData });
  
  // 查找或创建起始页标签
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('index.html') });
  if (tabs.length > 0) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
  }
}

// 检查是否是起始页
function isStartPage(url) {
  if (!url) return false;
  return url.startsWith(chrome.runtime.getURL(''));
}

// 显示通知
function showNotification(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: chrome.runtime.getURL('icons/icon128.png'),
    title: title,
    message: message
  });
}

// 监听来自起始页的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'getPendingEditApp':
      chrome.storage.local.get(['pendingEditApp']).then(result => {
        sendResponse({ success: true, data: result.pendingEditApp });
        chrome.storage.local.remove('pendingEditApp');
      });
      return true;
  }
});

console.log('[灵动起始页] Background Script 已加载');
